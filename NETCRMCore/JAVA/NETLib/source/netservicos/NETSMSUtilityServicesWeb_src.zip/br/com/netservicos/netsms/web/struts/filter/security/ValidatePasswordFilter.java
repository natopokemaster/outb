/**
 * Created on 29/06/2007
 * Project : NovoSMSWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: ValidatePasswordFilter.java,v 1.3.20.1 2009/08/14 17:30:47 anvlassov Exp $
 */
package br.com.netservicos.netsms.web.struts.filter.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.ArrayUtils;

import br.com.netservicos.framework.web.BaseFilter;


/**
 * <P><B>Description :</B><BR>
 * 	Filter that checks that the database name to display to the user is the same as 
 * the current database selected by the users session
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Jonatas Piscirilo
 * @since 03/07/2007
 */
public class ValidatePasswordFilter extends BaseFilter {

	private static final String PASSWORD_EXPIRED = "passwordExpired";
	private static final String EXCLUDE = "exclude";
	private String passwordExpired = "";
	private String[] excludeList;
	private FilterConfig filterConfig = null;

	/**
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		  passwordExpired =null;
		  excludeList =null;
	}

	/**
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
			
				
		String senhaExpirou = null;
		
		if (!ArrayUtils.contains(excludeList,((HttpServletRequest)request).getServletPath())){
			if( ((HttpServletRequest)request).getSession().getAttribute("senhaExpirada") !=null){
				senhaExpirou = ((HttpServletRequest)request).getSession().getAttribute("senhaExpirada").toString();
			}
				
			if("true".equals(senhaExpirou)){
				request.setAttribute("senhaExpirada", true);
			    filterConfig.getServletContext().getRequestDispatcher(passwordExpired).forward(request, response);
				return;
			}
		}
		filterChain.doFilter(request, response);
		    
	}

	/**
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig config) throws ServletException {
		this.filterConfig = config;
		passwordExpired = config.getInitParameter(PASSWORD_EXPIRED);
		excludeList = getFormattedValues(config.getInitParameter(EXCLUDE));
	}
	
}
