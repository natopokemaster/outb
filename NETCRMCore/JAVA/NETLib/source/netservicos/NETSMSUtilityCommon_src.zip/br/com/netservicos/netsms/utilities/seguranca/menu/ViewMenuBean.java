/*
 * Created on 30/08/2006
 *
 * Copyright � 2006 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 */
package br.com.netservicos.netsms.utilities.seguranca.menu;

import java.util.Collection;

import br.com.netservicos.framework.core.bean.DomainBean;

/**
 * <P><B>Description :</B><BR>
 * Entidade que representa uma view para o menu.
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Morgany
 * @since 21/06/2007
 * @version $Revision: 1.1 $
 */
public class ViewMenuBean extends DomainBean implements Comparable<ViewMenuBean>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6533148283083248352L;
	
	/**
	 * Constante respons�vel pela string de nome <br>
	 * do atributo de chave prim�ria
	 */
	private static final String PRIMARY_KEY = "id";
	
	private long id;
	
	private String descricaoMenu;
	
	private String applicationContext;
	
	private String url;
	
	private Collection<ViewMenuBean> children;
	
	private int ordem;
	
	/**
	 * Construtor parametrizado.
	 * @param primaryKey O nome da chave prim�ria no banco relacional.
	 */
	public ViewMenuBean(String primaryKey) {
		super(primaryKey);
	}
	
	/**
	 * Construtor padr�o
	 */
	public ViewMenuBean() {
		super(PRIMARY_KEY);
	}

	/**
	 * @return the applicationContext
	 */
	public String getApplicationContext() {
		return applicationContext;
	}

	/**
	 * @param applicationContext the applicationContext to set
	 */
	public void setApplicationContext(String applicationContext) {
		this.applicationContext = applicationContext;
	}

	/**
	 * @return the descricaoMenu
	 */
	public String getDescricaoMenu() {
		return descricaoMenu;
	}

	/**
	 * @param descricaoMenu the descricaoMenu to set
	 */
	public void setDescricaoMenu(String descricaoMenu) {
		this.descricaoMenu = descricaoMenu;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the ordem
	 */
	public int getOrdem() {
		return ordem;
	}

	/**
	 * @param ordem the ordem to set
	 */
	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the children
	 */
	public Collection<ViewMenuBean> getChildren() {
		return children;
	}

	/**
	 * @param children the children to set
	 */
	public void setChildren(Collection<ViewMenuBean> children) {
		this.children = children;
	}

	/**
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + (int) (id ^ (id >>> 32));
		return result;
	}

	/**
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final ViewMenuBean other = (ViewMenuBean) obj;
		if (id != other.id)
			return false;
		return true;
	}

	/**
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(ViewMenuBean o) {
		
		int result = 0;
		
		if ( o != null ) {
			
			result = new Integer( this.ordem ).compareTo( o.ordem );
			
			if ( result == 0 ){
				result = new Long( this.id ).compareTo( o.id );
			}
		}
		
		return result;
	}
}
