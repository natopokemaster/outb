//$Id: PostInsertEventListener.java,v 1.1 2007/11/05 12:11:30 rmgray Exp $
package org.hibernate.event;

import java.io.Serializable;

/**
 * Called after insterting an item in the datastore
 * 
 * @author Gavin King
 */
public interface PostInsertEventListener extends Serializable {
	public void onPostInsert(PostInsertEvent event);
}
