//$Id: AbstractClassTransformerImpl.java,v 1.1 2007/11/05 12:11:39 rmgray Exp $
package org.hibernate.bytecode;

import java.security.ProtectionDomain;
import java.util.HashSet;
import java.util.Set;

/**
 * @author Emmanuel Bernard
 */
public abstract class AbstractClassTransformerImpl implements ClassTransformer {

	final private Set entities;
	final private String[] packages;


	public AbstractClassTransformerImpl(String[] packages, String[] classes) {
		this.packages = packages;
		if (classes == null) {
			this.entities = null;
		}
		else {
			this.entities = new HashSet();
			for ( int i = 0; i < classes.length; i++ ) {
				entities.add( classes[i] );
			}
		}
	}

	public byte[] transform(
			ClassLoader loader,
			String className,
			Class classBeingRedefined,
			ProtectionDomain protectionDomain,
			byte[] classfileBuffer) {
		boolean enhance = false;
		String safeClassName = className.replace( '/', '.' );
		if ( entities == null && packages == null ) {
			enhance = true;
		}
		if ( ! enhance && entities != null && entities.contains( safeClassName ) ) {
			enhance = true;
		}
		if ( ! enhance && packages != null ) {
			for ( int i = 0; i < packages.length; i++ ) {
				if ( safeClassName.startsWith( packages[i] ) ) {
					enhance = true;
					break;
				}
			}
		}
		if ( ! enhance ) return classfileBuffer;

		return doTransform( loader, className, classBeingRedefined, protectionDomain, classfileBuffer );
	}

	protected abstract byte[] doTransform(
			ClassLoader loader,
			String className,
			Class classBeingRedefined,
			ProtectionDomain protectionDomain,
			byte[] classfileBuffer);
}
