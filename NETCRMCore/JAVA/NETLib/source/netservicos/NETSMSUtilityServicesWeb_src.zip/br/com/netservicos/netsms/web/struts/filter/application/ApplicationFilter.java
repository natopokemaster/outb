/**
 * Created on 23/07/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: ApplicationFilter.java,v 1.6 2008/05/09 13:14:06 jhpiscir Exp $
 */
package br.com.netservicos.netsms.web.struts.filter.application;

import static br.com.netservicos.framework.util.BaseConstants.ATRIBUTO_NET_SESSION_USER_INFO;
import static br.com.netservicos.framework.util.BaseConstants.CURRENT_DB_SERVICE;
import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTO_PREFIXO_DBSERVICE;
import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTO_PREFIXO_DBSERVICE_PER_APPLICATION;

import java.io.IOException;
import java.security.Principal;
import java.util.Hashtable;
import java.util.Properties;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.netservicos.framework.core.bean.UserInfo;
import br.com.netservicos.framework.util.loader.ApplicationResources;
import br.com.netservicos.framework.util.reflection.ReflectionUtil;

/**
 * <P><B>Description :</B><BR>
 * 	Filter used to always validate that the current application identifer is set in the user's session info
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 23/07/2007
 * @version $Revision: 1.6 $
 */
public class ApplicationFilter implements Filter {

	private static Log log = LogFactory.getLog(ApplicationFilter.class); 
	
	/**
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * Resets the current application identifer in the user session info  
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@SuppressWarnings("unchecked")
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		
		ApplicationResources applicationResources;
		HttpSession session = ((HttpServletRequest)request).getSession(false);
		UserInfo userInfo;
		
		if (session != null && 
				( userInfo = (UserInfo) session.getAttribute(ATRIBUTO_NET_SESSION_USER_INFO) ) != null) {
			
			applicationResources = (ApplicationResources) session.getServletContext().getAttribute( 
					ApplicationResources.APPLICATION_RESOURCES_KEY );
			userInfo.setCurrentApplicationIdentifier(
					applicationResources.getIdentifierApplication());
			
			Hashtable<String, String> applicationDatabasePrefixes = (Hashtable<String, String>) userInfo.getProperties().get(ATTRIBUTO_PREFIXO_DBSERVICE_PER_APPLICATION);
			if (applicationDatabasePrefixes != null) {
				String prefixoDBService = applicationDatabasePrefixes.get(applicationResources.getApplicationIdentifier());
				if (StringUtils.isNotBlank(prefixoDBService)) {
					userInfo.getProperties().setProperty(ATTRIBUTO_PREFIXO_DBSERVICE, prefixoDBService);
				}
			}
			
			//Sincronize the current db service between the userinfo and principal
			userInfo.setCurrentDbService(userInfo.getCurrentDbService());
			getPrincipalProperties(((HttpServletRequest)request)).setProperty(CURRENT_DB_SERVICE, userInfo.getCurrentDbService());
			

			
		} else {
			if (log.isDebugEnabled()) {
				log.debug("Not setting the applciation identifier, the user has not logged onto the system yet.");
			}
		}
		
		filterChain.doFilter(request, response);
	}

	/**
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	private Properties getPrincipalProperties(HttpServletRequest request) {

		Principal principal = request.getUserPrincipal();
		
		Properties result;
		try{
    		result = (Properties) ReflectionUtil.invokeMethod("getProperties", 
    				new Class[]{}, new Object[]{}, 
    				principal, principal.getClass());
		}catch (Exception e) {
			result = null;
		}
		return result;
	}

	
}
