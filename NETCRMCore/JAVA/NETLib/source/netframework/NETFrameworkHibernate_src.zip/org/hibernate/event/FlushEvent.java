//$Id: FlushEvent.java,v 1.1 2007/11/05 12:11:30 rmgray Exp $
package org.hibernate.event;


/** 
 * Defines an event class for the flushing of a session.
 *
 * @author Steve Ebersole
 */
public class FlushEvent extends AbstractEvent {
	
	public FlushEvent(EventSource source) {
		super(source);
	}

}
