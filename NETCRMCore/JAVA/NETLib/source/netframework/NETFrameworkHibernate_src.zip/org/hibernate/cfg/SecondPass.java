//$Id: SecondPass.java,v 1.1 2007/11/05 12:11:35 rmgray Exp $
package org.hibernate.cfg;

import java.io.Serializable;

import org.hibernate.MappingException;

/**
 * Second pass operation
 *
 * @author Emmanuel Bernard
 */
public interface SecondPass extends Serializable {

	void doSecondPass(java.util.Map persistentClasses, java.util.Map inheritedMetas)
				throws MappingException;

}
