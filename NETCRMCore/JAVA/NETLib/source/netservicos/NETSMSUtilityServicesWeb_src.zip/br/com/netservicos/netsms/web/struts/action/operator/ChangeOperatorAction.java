/**
 * Created on 20/07/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: ChangeOperatorAction.java,v 1.7.12.1 2009/07/29 18:21:01 anvlassov Exp $
 */
package br.com.netservicos.netsms.web.struts.action.operator;

import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTE_MENU;
import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTO_PREFIXO_DBSERVICE;
import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.KEY_CURRENT_CID_CONTRATO;
import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.KEY_CURRENT_OPERATOR_NAME;
import static br.com.netservicos.netsms.web.taglib.ui.OperatorSelectTag.ATTRIBUTE_OPERATOR_SELECTED_NAME;
import static br.com.netservicos.netsms.web.taglib.ui.OperatorSelectTag.ATTRIBUTE_OPERATOR_SELECT_ACTION;
import static br.com.netservicos.netsms.web.taglib.ui.OperatorSelectTag.ATTRIBUTE_OPERATOR_SELECT_NAME;

import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import br.com.netservicos.framework.core.bean.UserInfo;
import br.com.netservicos.framework.core.bean.UserInfoImpl;
import br.com.netservicos.framework.util.BaseConstants;
import br.com.netservicos.framework.web.authentication.Authentication;
import br.com.netservicos.framework.web.authentication.AuthenticationFactory;
import br.com.netservicos.framework.web.struts.action.SimpleCadAction;
import br.com.netservicos.netsms.utilities.operator.bean.OperatorDTO;
import br.com.netservicos.netsms.web.utils.MenuUtils;
import br.com.netservicos.netsms.web.utils.OperatorSelectUtils;

/**
 * <P><B>Description :</B><BR>
 * 	TODO descrever
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 20/07/2007
 * @version $Revision: 1.7.12.1 $
 * 
 * @author Anton Vlassov
 * @since 29/07/2007
 * Corrigido: mesmo no caso de relogin falhar, atualizava o userinfo. Adiconado um else para tratar
 */
public class ChangeOperatorAction extends SimpleCadAction {

	
	/**
	 * 
	 * @see org.apache.struts.actions.DispatchAction#unspecified(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public ActionForward unspecified(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String idSelectTag = request.getParameter(ATTRIBUTE_OPERATOR_SELECT_NAME);
		String action = request.getParameter(ATTRIBUTE_OPERATOR_SELECT_ACTION);
		String nomeOperadoraSelecionado = request.getParameter(ATTRIBUTE_OPERATOR_SELECTED_NAME);

		OperatorDTO operatorDTO = OperatorSelectUtils.getSelectedOperator(request, idSelectTag);
		UserInfo userInfo = getUserInfo(request);
		UserInfo newUserInfo;
		
		String cidContratoOld = userInfo.getProperties().getProperty(KEY_CURRENT_CID_CONTRATO);
		
		if (!userInfo.getCurrentDbService().equals(operatorDTO.getDbService())) {
			
			userInfo.setCurrentDbService(operatorDTO.getDbService());
			getPrincipalProperties(request.getUserPrincipal()).setProperty(BaseConstants.CURRENT_DB_SERVICE, operatorDTO.getDbService());
			
			String prefixoDBService = userInfo.getProperties().getProperty(ATTRIBUTO_PREFIXO_DBSERVICE);
			
			String databaseIdentity = operatorDTO.getDbService().substring(prefixoDBService.length()) + "_" + operatorDTO.getCidContrato();
			
			Authentication authentication = AuthenticationFactory.getInstance().getDefaultAuthentication();
			
			boolean authenciated = authentication.reloginUser(request, userInfo.getUserId(), databaseIdentity);
			if (!authenciated) {
				// N�O AUTORIZADO envia c�digo de status 403
				response.sendError( HttpServletResponse.SC_UNAUTHORIZED );
			} else {
				
				// Copia propriedades que nao sao provenientes da authenticacao, ou seja, que nao sao 
				// configuradas pelo provider.
				// Primeiro remove as propriedades no user info anterior que vieram da autheticacao
				Properties autheticantionProperties = getPrincipalProperties( 
						request.getUserPrincipal() );
				Properties oldUserInfoProperties = userInfo.getProperties();
				
				for( Object key: autheticantionProperties.keySet() ) {
					
					if ( userInfo.getProperties().containsKey( key ) ) {
						oldUserInfoProperties.remove(key);
					}
				}
				// copia propriedades restantes no userinfo anterior para o novo principal
				autheticantionProperties.putAll( oldUserInfoProperties );
				// cria novo userinfo
				newUserInfo = new UserInfoImpl( request.getUserPrincipal(), 
						autheticantionProperties );
				

				newUserInfo.setSelectedDbServices(userInfo.getSelectedDbServices());
				newUserInfo.setCurrentDbService(operatorDTO.getDbService());
				newUserInfo.setCurrentApplicationIdentifier(userInfo.getCurrentApplicationIdentifier());
				newUserInfo.setCurrentSystemIdentifier(userInfo.getCurrentSystemIdentifier());
				newUserInfo.getProperties().setProperty(ATTRIBUTO_PREFIXO_DBSERVICE, prefixoDBService);
				request.getSession().setAttribute(ATRIBUTO_NET_SESSION_USER_INFO, newUserInfo);
				
		        Map<String, Map<String, Object>> menu = MenuUtils.getPrincipalMenu(request);
		        request.getSession().setAttribute(ATTRIBUTE_MENU, menu);
		        
		        // altera as informa��es do userinfo, no caso de reautentica��o
				getUserInfo(request).getProperties().setProperty(KEY_CURRENT_CID_CONTRATO, operatorDTO.getCidContrato());
				getUserInfo(request).getProperties().setProperty(KEY_CURRENT_OPERATOR_NAME, nomeOperadoraSelecionado);
			}
		} else {
			// altera userinfo, caso as operados s�o da mesma base, mas cidContrato diferentes (portanto, nao necessitam de relogin)
			if (!cidContratoOld.equals(operatorDTO.getCidContrato())) {
				getUserInfo(request).getProperties().setProperty(KEY_CURRENT_CID_CONTRATO, operatorDTO.getCidContrato());
				getUserInfo(request).getProperties().setProperty(KEY_CURRENT_OPERATOR_NAME, nomeOperadoraSelecionado);
			}
		}
		
		return new ActionForward(action);
	}


}
