package br.com.netservicos.netsms.web.struts.filter.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.netservicos.framework.web.BaseFilter;

/**
 * 
 * Filtro que detecta a ocorrencia de caracteres passiveis de representar um ataque de
 * crossitescripting durante acesso ao servlet DWR. Caso detectados, redireciona
 * para pagina padr�o do framework
 * 
 * Exemplo de caracteres: ' < > & etc.
 * 
 * A lista de caracteres ofensivos, assim como o redirect deve ser configurado
 * no web.xml como init parameter desye filtro.
 * 
 * @author Anton Vlassov
 *
 */
public class DWRCrossSiteScriptingFilter extends BaseFilter {
	
	private static final Log log = LogFactory.getLog(DWRCrossSiteScriptingFilter.class);
    
	private final static String REDIRECT_TO = "redirectTo";
	private final static String OFFENSIVE_CHARS = "offensiveChars";
	
	private String redirectTo;
	private String [] offensiveChars;
	
	
	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		
		if( request  instanceof HttpServletRequest ) {
			
			HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			
			// realiza valida��o e caso detecte caracteres ofensivos, redireciona para
			// uma pagina padr�o de erro de crosssite scripting
			if(!validate(httpServletRequest.getRequestURI()) || !validate(httpServletRequest.getQueryString())) {
				httpServletRequest.getRequestDispatcher(redirectTo).forward(request, response);
				return;
			}
		}
		
		filterChain.doFilter(request, response);

	}
	
	/**
	 * Realiza a validacao do parametro em rela��o a ocorrencia de caracteres ofensivos configurados 
	 * @param requestStr
	 * @return
	 */
	private Boolean validate(String requestStr) {
	   
		if(StringUtils.isNotBlank(requestStr) ) {
			
			// IE efetua traducao - converte to ASCII
			// Firefox - hexadecimal - trata diretamente
			for(String hexaChar : offensiveChars) {
				if(requestStr.indexOf(convertToASCII(hexaChar)) != -1 ) return false;
				if(requestStr.indexOf(hexaChar) != -1 ) return false;
			}
		}
		
		return true;
	}
	
	

	public void init(FilterConfig config) throws ServletException {
		redirectTo = config.getInitParameter(REDIRECT_TO);
		offensiveChars = getFormattedValues(config.getInitParameter(OFFENSIVE_CHARS));
	}
	

	/**
	 * Realiza conversao do hexa para ASCII
	 * @since 10/08/2009
	 * @param hexaCharStr
	 * @return
	 */
	private String convertToASCII(String hexaCharStr) {
		String s = "";
		try {
		    int n = Integer.parseInt(hexaCharStr.substring(1), 16);
		    n &= 0xFF; // Sometimes (not here) you get sign extension, n < 0
		    char ch = (char)n;
		     s = "" + ch;
		} catch (Exception e) {
			if(log.isDebugEnabled()) 
				log.debug("Unable to parse hexa char "+hexaCharStr+" , ignoring..."+e.getMessage());
		}
		return s;
	}
	
	
	/**
	 * 
   3.         ...  
   4.         for (char ch : teste.toCharArray())  
   5.             System.out.print(Integer.toHexString(ch) + " ");  
	 * 
	 */
}
