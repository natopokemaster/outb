package br.com.netservicos.netsms.web.taglib.ui;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;


public class MenuTag extends TagSupport {
	 
	private static final long serialVersionUID = 1L;
				
	protected String urlPrefixo;

	
	public int doStartTag() throws JspTagException {
		
		StringBuffer requestURL = ((HttpServletRequest)super.pageContext.getRequest()).getRequestURL(); 
		String contextPath = ((HttpServletRequest)super.pageContext.getRequest()).getContextPath();
		
		urlPrefixo = requestURL.substring(0, requestURL.indexOf(contextPath) + 1 );
		
    	Map<String, Object> itens = getItensMenu();
    	
    	String menu = montaMenu(itens);
		
		try {
			pageContext.getOut().write(menu);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return EVAL_BODY_INCLUDE;
	}
	
	/**
	 * Recupera os itens de menu do usu�rio atual
	 * @return Collection de ItensMenuDTO
	 */
	@SuppressWarnings("unchecked")
	protected Map<String, Object> getItensMenu(){
						
		HttpServletRequest request = (HttpServletRequest) super.pageContext.getRequest();
		
		Map<String, Object> menu = (Map<String,Object>) request.getSession().getAttribute("userMenu");
		
		//montaMenu(menu);
				
		return menu;
	}
	
	@SuppressWarnings("unchecked")
	protected String montaMenu(Map itens){
		StringBuilder builder = new StringBuilder();
		int indice = 1;
		builder.append("tree" + indice + " = foldersTree").append( "\n" );
		gerarMenu(builder,itens,indice,1);
		return builder.toString();
		
	}
	
	@SuppressWarnings("unchecked")
	protected void gerarMenu(StringBuilder builder, Map menu, int indice,int level){
		
		int index = 0;
		
		for (Iterator iterator = menu.entrySet().iterator(); iterator.hasNext();) {
			
			Map.Entry<String, Object> entry = (Map.Entry<String, Object>) iterator.next();
			
			Map<String,Object> nivel2 =null;
			index++;
			
			if(entry.getValue() != null && Map.class.isInstance( entry.getValue() )){
				builder
				.append("tree" )
				.append( indice + (index * (int)Math.pow(10, level )) )
				.append(" = insFld(tree" ).append( indice )
				.append(", gFld(TAG_A+'" ).append( index )
				.append( " - " )
				.append(entry.getKey() )
				.append( "'+TAG_C))")
				.append( "\n" );
			    
				nivel2 = (Map)entry.getValue();
				gerarMenu(builder,nivel2,indice + (index * (int)Math.pow(10, level )),level+1);
			
			} else {
				
				builder.append("insDoc(tree" + indice + ", gLnk('S', TAG_A1+'"	+ index 
						 + " - " + entry.getKey() + "'+TAG_B('','" + level + "'), '" +
						 urlPrefixo + entry.getValue() + "'))").append( "\n" ); 
				
			/*	builder.append("insDoc(tree" + indice + 
						 ", gLnk('S', TAG_A1+'"	+ index 
						 + " - " + entry.getKey() +	"'+, '" +
						entry.getValue() + "'))").append( "\n" ); */
							
			}
		}
	}


	 
	/** exemplo para montar o menu 
	 * 
	 * 
	@SuppressWarnings("unchecked")
	public String montaMenu(Map<String, Object> itens) {
				
		StringBuffer buf = new StringBuffer();
		int treeRaiz = 1;
		int tree = 1;
		// monta arvore inicial	
		buf.append("tree" + treeRaiz + " = foldersTree");
		buf.append(ENTER);
		
		// monta submenus
		int subIndice = 0;
		for (Iterator iterator = itens.entrySet().iterator(); iterator.hasNext();) {
			tree++;
			Map.Entry<String, Object> entry = (Map.Entry<String, Object>) iterator.next();
			buf.append("tree" +  tree +
					   " = insFld(tree"
					   + treeRaiz + 
					   ", gFld(TAG_A+'" + subIndice++ + " - " + 
					   entry.getKey() + "'+TAG_C))");
			buf.append(ENTER);
			
			//adiciona links
			Map<String,Object> nivel2 = (Map)entry.getValue();
			int indice = 0;
			for (Iterator iterator1 = nivel2.entrySet().iterator(); iterator1.hasNext();) {
				Map.Entry<String, Object> entry2 = (Map.Entry<String, Object>) iterator1.next();
				buf.append("insDoc(tree" + tree + 
					 ", gLnk('S', TAG_A1+'"	+ indice++ 
					 +
					" - " + entry2.getKey() + 
					"'+TAG_B('" + "KOLIREIS" + "','" + 3 + "'), '" +
					"teste" + ".do" + "?service="
					+ "testeservice" + "'))");
				buf.append(ENTER);
			}
			buf.append(ENTER);
		}
					
    	return buf.toString();  
		
    }*/
}