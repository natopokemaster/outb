/**
 * Created on 09/07/2007
 * Project : NETSMSUtilityServices
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: NETSMSSecurityEJBImpl.java,v 1.14.2.3 2009/08/03 21:47:22 anvlassov Exp $
 */
package br.com.netservicos.netsms.utilities.security.facade.impl;



import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.security.auth.login.FailedLoginException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.netservicos.framework.ad.NETADUserEngine;
import br.com.netservicos.framework.ad.NETADUserEngineWrapper;
import br.com.netservicos.framework.ad.PasswordStatus;
import br.com.netservicos.framework.ad.PasswordStatus.PasswordStatusEnum;
import br.com.netservicos.framework.ad.exception.ADException;
import br.com.netservicos.framework.ad.exception.LDAPADException;
import br.com.netservicos.framework.ad.user.IADUser;
import br.com.netservicos.framework.auth.util.jaas.BaseUser;
import br.com.netservicos.framework.core.bean.Bean;
import br.com.netservicos.framework.core.bean.DynamicBean;
import br.com.netservicos.framework.core.dao.BatchParameter;
import br.com.netservicos.framework.core.dao.DAO;
import br.com.netservicos.framework.core.dao.SecurityJDBCDAO;
import br.com.netservicos.framework.core.facade.hibernate.AbstractSimpleCadEJBImpl;
import br.com.netservicos.framework.util.exception.BaseFailureException;
import br.com.netservicos.netsms.utilities.operator.bean.OperatorDTO;
import br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService;


/**
 * <P><B>Description : Servi�o EJB criado para valida��o/autentica��o do usu�rio no banco de dados </B><BR>
 * 
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Thiago Elias Souza
 * @since 11/07/2007
 * @version $Revision: 1.14.2.3 $
 * 
 * @ejb.bean name="NETSMSSecurityEJB"
 * 		type="Stateless"
 * 		display-name="NETSMSSecurityEJB"
 *      description="NETSMSSecurityEJB Session EJB Stateless"
 *      view-type="both"
 *      jndi-name="@APPLICATION/novosms/utilities/ejb/NETSMSSecurityEJB"
 * 		local-jndi-name="@APPLICATION/novosms/utilities/ejb/local/NETSMSSecurityEJB"
 *      transaction-type="Container"
 * 	
 * @ejb.interface
 *   local-extends="javax.ejb.EJBLocalObject"
 *   extends="javax.ejb.EJBObject"
 *
 * @ejb.home
 *   local-extends="javax.ejb.EJBLocalHome"
 *   extends="javax.ejb.EJBHome"
 * 
 * @ejb.env-entry name="identifierApplication" type="java.lang.String" value="NETSMSUtilityServices"
 * 
 */
public class NETSMSSecurityEJBImpl extends AbstractSimpleCadEJBImpl implements NETSMSSecurityService {

	/**
	 * Serial Version
	 */
	private static final long serialVersionUID = 2721922805104503427L;
	
	private static final Log log = LogFactory.getLog(NETSMSSecurityEJBImpl.class);
	
	
	/**
	 * @ejb.create-method
	 * @ejb.permission unchecked="true"
	 * @see br.com.netservicos.framework.core.facade.hibernate.AbstractSimpleCadEJBImpl#ejbCreate()
	 */
	@Override
	public void ejbCreate() throws CreateException {
		super.ejbCreate();
	}
	
	/**
	 * @ejb.permission unchecked="true"
	 * @see br.com.netservicos.framework.core.facade.EJBImpl#ejbRemove()
	 */
	@Override
	public void ejbRemove() throws EJBException {
		super.ejbRemove();
	}
	
	/**
	* Implementa��o do m�todo validateUser para autentica��o do usu�rio
	* Executa chamada da Store procedure PSN_SENHAS.SSN_VALIDASENHA
	*
	* @param userName - nome do usu�rio
	* @param userPassword - senha do usu�rio
	*
	* @return retorna valor booleano: 
	* true = autenticado 
	* false =  erro / ou usu�rio n�o autenticado)
	*
	* @exception BaseFailureException
	*
	* @since 13/07/2007
    * @ejb.interface-method view-type="both"
	* @ejb.transaction type="Required"
	* @ejb.permission role-name="ACESSO"
	*/
	public boolean validateUser(String userName, String userPassword) throws BaseFailureException {
		
		Boolean valid = Boolean.FALSE;
		
		
		if (StringUtils.isBlank(userName)) {
			throw new BaseFailureException("Nome de usuario e obrigatorio.");
		}

		if (StringUtils.isBlank(userPassword)) {
			throw new BaseFailureException("Senha de usuario e obrigatorio.");
		}

		
		try {
		
			BatchParameter[] batchParameters = new BatchParameter[]{
					new BatchParameter(userName, Types.VARCHAR),
					new BatchParameter(userPassword, Types.VARCHAR),
					new BatchParameter(Types.FLOAT, true),
					new BatchParameter(Types.FLOAT, true),
					new BatchParameter(Types.NUMERIC, true),
					new BatchParameter(Types.VARCHAR, true) };
			
			List<Object> results = getDAO(userInfo.getCurrentDbService()).executeBatch("{call PSN_SENHAS.SSN_VALIDASENHA(?,?,?,?,?,?)}", batchParameters);
			
			// Retrieving the valid login flag (1 = invalid login | 0 = valid login)
			Float validLogin = Float.parseFloat( results.get(2).toString()); 
			// Retrieving the expired password flag (1 = expired | 0 = not expired)
			Float expired = Float.parseFloat( results.get(3).toString()); 
			// Retrieving the error code to be verifyied
			Float errorCode = Float.parseFloat( results.get(4).toString()); 
			
			if (errorCode == 6 || errorCode == 10 || errorCode == 8 || errorCode == 7 || errorCode == 5 ) {
				throw new FailedLoginException(results.get(5).toString());
			} else if (expired == 0 && validLogin == 0) {
				valid = Boolean.TRUE;
			}
				
		} catch (Exception e) {
			throw new BaseFailureException("Erro na valida��o do usuario", e);
		}

		return valid;
	}
	
	
	
	/**
	* @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#changePassword(java.lang.String, java.lang.String, java.lang.String)
	* @since 08/11/2007
    * @ejb.interface-method view-type="both"
	* @ejb.transaction type="Required"
	* @ejb.permission role-name="ACESSO"
	*/
	public void changePassword(String userName, String actualPassword, String newPassword){
		
		try{
			
			BatchParameter[] batchParameters = new BatchParameter[]{
				new BatchParameter(userName, Types.VARCHAR),
				new BatchParameter(actualPassword, Types.VARCHAR),
				new BatchParameter(newPassword, Types.VARCHAR),
				new BatchParameter(Types.NUMERIC, true),
				new BatchParameter(Types.VARCHAR, true) };
		
			List<Object> results = getDAO(userInfo.getCurrentDbService()).executeBatch("{call PSN_SENHAS.SSN_ALTERASENHA(?,?,?,?,?)}", batchParameters);
			Float errorCode = null;
			
			if(results.get(3) !=null){
			  errorCode = Float.parseFloat(results.get(3).toString());
			}
			if(errorCode!=null && errorCode!=0){
				String msg = null;
				if(results.get(4)!=null){
					 msg = results.get(4).toString();
				}else{
					msg = "Erro ao tentar efetuar a troca de senha";
				}
				throw new FailedLoginException(msg);
			}
		}catch(Exception e){
			throw new BaseFailureException("Erro ao tentar efetuar a troca de senha do usuario", e);
		}
	}

	
	
	/**
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
	 * @ejb.permission role-name="ACESSO"
	 * @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#validateUser(java.lang.String, java.lang.String, java.lang.String)
	 */
	public Boolean validateUser(String userName, String userPassword,
			String role) {
		
		
		if (validateUser(userName, userPassword)) {
			return isUserInRole(userName, role);
		} else {
			return Boolean.FALSE;
		}
	}

	/**
	 * @ejb.interface-method view-type="both"
	 * @ejb.transaction type="Required"
	 * @ejb.permission role-name="ACESSO"
	 * @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#isUserInRole(java.lang.String, java.lang.String)
	 */
	public Boolean isUserInRole(String userName, String role) {
		return this.isUserInRole(userName, role, super.getUserSession().getCurrentDbService(), super.getUserSession().getCurrentApplicationIdentifier());
	}

	/**
	 * @ejb.interface-method view-type="both"
	 * @ejb.transaction type="Required"
	 * @ejb.permission role-name="ACESSO"
	 * @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#isUserInRole(java.lang.String, java.lang.String, String, String)
	 */
	public Boolean isUserInRole(String userName, String role, String dbService, String siglaAplicacao) {
		
		StringBuffer sql = new StringBuffer();
		sql.append(" SELECT FUNCIONALIDADE.ID_FUNCIONALIDADE ");
		sql.append(" 	FROM PERFIL.PR_FUNCIONARIO        FUNCIONARIO, ");
		sql.append(" 			 PERFIL.PRSEG_REL_PERFIL_FNCD PERFILFUNCIONALDIADE, ");
		sql.append(" 			 PERFIL.PRSEG_FUNCIONALIDADE  FUNCIONALIDADE ");
		sql.append("  WHERE FUNCIONARIO.ID_PERFIL = PERFILFUNCIONALDIADE.ID_PERFIL ");
		sql.append(" 	 AND FUNCIONALIDADE.ID_FUNCIONALIDADE = ");
		sql.append(" 			 PERFILFUNCIONALDIADE.ID_FUNCIONALIDADE ");
		sql.append(" 	 AND FUNCIONARIO.USERNAME = '" + userName + "' ");
		sql.append(" 	 AND FUNCIONALIDADE.SG_FUNCIONALIDADE = '" + role + "' ");
		sql.append(" 	 AND FUNCIONALIDADE.SG_APLICACAO = '" + siglaAplicacao + "' ");
		
		DAO dao = super.getDAOFactory().getDAO(DAO.JDBC_DAO, dbService);
		Collection<DynamicBean> funcionalidades = dao.select(sql.toString());
		
		return funcionalidades.size() > 0;
	}
	
	/**
     * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission role-name="ACESSO"
	 * @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#searchOperadorasParaUsuario(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public Collection<OperatorDTO> searchOperadorasParaUsuario(String siglaFuncionalidade) {
		
		StringBuffer sql = new StringBuffer();
		
		sql.append(" SELECT DISTINCT CIDADE_OPERADORA.CID_CONTRATO AS CID_CONTRATO, CIDADE_OPERADORA.CI_NOME AS NOME ");
		sql.append(" 	FROM 	PERFIL.PR_FUNCIONARIO           FUNCIONARIO, ");
		sql.append(" 			PERFIL.PR_PERFIL                PERFI, ");
		sql.append(" 			PERFIL.PR_REL_PERFIL_NIVEL_OPER PREFIL_NIVEL_OPER, ");
		sql.append(" 			PERFIL.PR_NIVEL_OPER            NIVEL_OPER, ");
		sql.append(" 			PERFIL.PR_SN_EMPRESA            EMPRESA, ");
		sql.append(" 			SN_CIDADE_OPERADORA             CIDADE_OPERADORA, ");
		sql.append(" 			PERFIL.PRSEG_REL_PERFIL_FNCD    REL_PERFIL_FNCD, ");
		sql.append(" 			PERFIL.PRSEG_FUNCIONALIDADE     FUNC ");
		sql.append("  WHERE PERFI.ID_PERFIL = FUNCIONARIO.ID_PERFIL ");
		sql.append(" 	 AND PERFI.ID_PERFIL = PREFIL_NIVEL_OPER.ID_PERFIL ");
		sql.append(" 	 AND PERFI.ID_PERFIL = REL_PERFIL_FNCD.ID_PERFIL ");
		sql.append(" 	 AND FUNC.ID_FUNCIONALIDADE = REL_PERFIL_FNCD.ID_FUNCIONALIDADE ");
		sql.append(" 	 AND PREFIL_NIVEL_OPER.ID_NIVEL_OPER = NIVEL_OPER.ID_NIVEL_OPER ");
		sql.append(" 	 AND NIVEL_OPER.ID_NIVEL_OPER = EMPRESA.ID_NIVEL_OPER ");
		sql.append(" 	 AND EMPRESA.ID_EMPRESA = CIDADE_OPERADORA.ID_EMPRESA ");
		sql.append(" 	 AND FUNCIONARIO.USERNAME = '").append(super.userInfo.getUserId()).append("'");
		sql.append(" 	 AND FUNC.SG_FUNCIONALIDADE = '").append(siglaFuncionalidade).append("'");
		sql.append(" 	 AND NIVEL_OPER.ID_SIS = ").append(super.userInfo.getCurrentSystemIdentifier());
		
		String[] dbServices = super.userInfo.getSelectedDbServices();
		String currentDBService = super.userInfo.getCurrentDbService();
		
		List<OperatorDTO> operators = new ArrayList<OperatorDTO>();
		DAO dao = null;
		for (int i = 0; i < dbServices.length; i++) {
			
			try {
			
				super.userInfo.setCurrentDbService(dbServices[i]);
				dao = super.getDAOFactory().getDAO(DAO.JDBC_DAO, dbServices[i]);
				Collection<DynamicBean> operatorsBase = dao.select(sql.toString());
				
				for (DynamicBean dynamicBean : operatorsBase) {
					OperatorDTO operatorDTO = new OperatorDTO(dbServices[i], (String)dynamicBean.get("CID_CONTRATO"), (String)dynamicBean.get("NOME"));
					operators.add(operatorDTO);
				}
			
			} catch (Exception e) {
				log.error("Error trying to find the operators for the database " + dbServices[i] + " and user " + super.userInfo.getUserId(), e);
			}
		}

		//Return the current dbService to the original dbService
		super.userInfo.setCurrentDbService(currentDBService);
		
		Collections.sort(operators, new Comparator<OperatorDTO>() {

			/**
			 * Compare the Name of the operator
			 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
			 */
			public int compare(OperatorDTO o1, OperatorDTO o2) {
				if (o1.getNameOperator() == null || o2.getNameOperator() == null) {
					return -1;
				}
				return o1.getNameOperator().compareTo(o2.getNameOperator());
			}
			
		});
		
		return  operators;
	}
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true" 
	 * 
	 * @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#searchUsingFirstAvailableDatabase(java.lang.String, br.com.netservicos.framework.core.bean.Bean)
	 */
	@SuppressWarnings("unchecked")
	public List searchUsingFirstAvailableDatabase(String queryName, Bean bean) {
		return searchUsingFirstAvailableDatabase(queryName, bean, Boolean.TRUE);
	}
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * 
	 * @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#searchUsingFirstAvailableDatabase(java.lang.String, br.com.netservicos.framework.core.bean.Bean, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public List searchUsingFirstAvailableDatabase(String queryName, Bean bean, Boolean cache) {
		
		List results = null;
		String[] dbServices = super.getUserSession().getSelectedDbServices();
		for (int i = 0; i < dbServices.length; i++) {
			try {
				if (log.isDebugEnabled()) {
					log.debug("Utilizing the database service : " + dbServices[i] + 
							" to perform the prepareSearch function of the login action.");
				}

				results =super.getDAO(dbServices[i]).select(queryName, bean, cache);
				break;
			} catch (Exception ignoreException) {
				if (log.isDebugEnabled()) {
					log.debug("Error utilizing the database service : " + dbServices[i] + 
							" to perform the prepareSearch function of the login action.", ignoreException);
				}
			}
		}
		return results;
	}
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * 
	 * @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#searchAllActiveOperators(java.lang.String, br.com.netservicos.framework.core.bean.Bean)
	 */
	@SuppressWarnings("unchecked")
	public List searchAllActiveOperators(String queryName, Bean bean) {
		return searchAllActiveOperators(queryName, bean, Boolean.TRUE);
	}
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * 
	 * @see br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService#searchAllActiveOperators(java.lang.String, br.com.netservicos.framework.core.bean.Bean, java.lang.Boolean)
	 */
	@SuppressWarnings("unchecked")
	public List searchAllActiveOperators(String queryName, Bean bean, Boolean cache) {
		
		String[] dbServices = super.getUserSession().getSelectedDbServices();
		String[] dbAliases = new String[dbServices.length];
		
		String dbServicePrefixo = bean.getBeanProperty("dbServicePrefixo");
		if (dbServicePrefixo != null) {
			
			for (int i = 0; i < dbServices.length; i++) {
				dbAliases[i] = dbServices[i].substring(dbServices[i].indexOf(dbServicePrefixo) + dbServicePrefixo.length());
			}
			
		} else {
			log.error("Parameter dbServicePrefixo not found for the execution of searchAllActiveOperators");
		}
		
		DynamicBean filterBean = new DynamicBean();
		filterBean.set("baseAliases", Arrays.asList(dbAliases));
		
		return searchUsingFirstAvailableDatabase(queryName, filterBean, cache);
	}
	
	
	/**
	 * Obtem o menu a partir dos DataSources de PERFIL ( que devem estar previamente configurados dentro
	 * de applicationContext-security-config.xml fornecido pela aplica��o)
	 * @since 23/07/2009
	 * @param principal
	 * @return Map que representa o Menu
	 * 
	 * @ejb.interface-method view-type="both"
	 * @ejb.transaction type="Required"
	 * @ejb.permission role-name="ACESSO"
	 */
	public Map<String, Object> getMenu(String username, String securityDbService) {
		
		// obtem security DAO para o dbService se seguran�a corrente
		SecurityJDBCDAO securityDAO = SecurityJDBCDAO.class.cast(super.getDAOFactory().getDAO(DAO.SECURITY_DAO, securityDbService));
		
		// obtem o meno para o usuario atraves do sistema de perfil
		return securityDAO.getMenu(username, new String[] {super.userInfo.getCurrentSystemIdentifier()});
		
	}
	
	/**
	 * Obtem informa��es basicas do Usuario a partir do Active Directory
	 * @since 24/07/2009
	 * @param principal
	 * @return
	 * 
	 * @ejb.interface-method view-type="both"
	 * @ejb.transaction type="Required"
	 * @ejb.permission role-name="ACESSO"
	 */
	public BaseUser getBaseUser(String username, Boolean loadPasswordStatus) {
		
		// cria uma BaseUser default
		BaseUser baseUserLogin = new BaseUser(username);
		
		// obtem a configura��o do engine e recupera info do usuario
		NETADUserEngine engine = null;
		IADUser user = null;
		try {
			engine = NETADUserEngineWrapper.getInstance();
			user = engine.getLDAPUser(username);
		} catch (LDAPADException e) {
			if(log.isErrorEnabled())
				 log.error("Error retrieving BaseUser info from LDAP, will be initialized with logged username only");
		} catch (ADException e) {
			if(log.isErrorEnabled())
				 log.error("Error retrieving BaseUser info from AD, will be initialized with logged username only");
		}
		
		// se recuperou usuario com sucesso do AD, configura informa��es adicionais
		// e recupera info sobre expira��o da senha
		if(user != null) {
	        baseUserLogin.setName(user.getFullName());
	        baseUserLogin.setLogin(user.getLogin());
	        baseUserLogin.setEmail(user.getMail());
	        
	        // caso especificado, carrega o status da senha
	        if(loadPasswordStatus){
	        
		        PasswordStatus passwordStatus = null;
		        try {
					passwordStatus = engine.getPasswordStatus(user);
				} catch (LDAPADException e) {
					if(log.isErrorEnabled())
						 log.error("Error retrieving password expiration info from LDAP, will be initialized as NOT_EXPIRED");
				}
				
				if (passwordStatus != null) {
					if (passwordStatus.getPasswordStatusEnum().equals(PasswordStatusEnum.PASSWORD_EXPIRED)) {
						baseUserLogin.setPasswordExpired(passwordStatus.getQuantityDays());
					} else if (passwordStatus.getPasswordStatusEnum().equals(PasswordStatusEnum.PASSWORD_EXPRING)) {
						baseUserLogin.setPasswordExpiring(passwordStatus.getQuantityDays());
					}
				}
	        }
	        
		}
        
		return baseUserLogin;
	}
	
	
	/**public void recarregarRoles(HttpServletRequest request) {
		
		// obtem AutnenticatedSubject
		request.getSession().getServletContext();

		//WebAppServletContext webappservletcontext = (WebAppServletContext)((HttpSession)sessioninternal).getServletContext();
		WebAppServletContext webappservletcontext = (WebAppServletContext)request.getSession().getServletContext();
		AuthenticatedSubject authenticatedsubject = SecurityModule.getCurrentUser(webappservletcontext.getServer(), request);
		
		// obtem os roles
		Set <WLSGroup> roles = authenticatedsubject.getPrincipals(WLSGroup.class);
		authenticatedsubject.getPrincipals().removeAll(roles);
		
	
		
		// obtem os Principals so Subject
		
		// obtem e remove os principals do tipo WLSGroup
		
		// carrega os Roles (FUNCIONALIDADE) via JDBC
		
		
	}
	
	
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * @see br.com.netservicos.framework.core.facade.hibernate.AbstractSimpleCadEJBImpl#find(br.com.netservicos.framework.core.bean.Bean)
	 * @deprecated utilizar o m�todo <code>findByPrimaryKey(Bean bean)</code>, este metodo estava lancando 
	 * o exe��o se o objeto n�o foi encontrado
	 */
	@Override
	public Bean find(Bean bean) {
		return super.find(bean);
	}

	
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * @see br.com.netservicos.framework.core.facade.hibernate.SimpleCad#findByPrimaryKey(br.com.netservicos.framework.core.bean.Bean)
	 */
	@Override
	public Bean findByPrimaryKey(Bean bean) {
		return super.findByPrimaryKey(bean);
	}

	/**
	 * 
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * @see br.com.netservicos.framework.core.facade.hibernate.AbstractSimpleCadEJBImpl#searchLists(java.lang.String[], br.com.netservicos.framework.core.bean.Bean)
	 */
	@Override
	public Collection[] searchLists(String[] queryNames, Bean bean) {
		return super.searchLists(queryNames, bean);
	}
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * @see br.com.netservicos.framework.core.facade.hibernate.AbstractSimpleCadEJBImpl#search(java.lang.String, br.com.netservicos.framework.core.bean.Bean)
	 */
	@Override
	public List search(String queryName, Bean bean) {
		return super.search(queryName, bean);
	}
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * @see br.com.netservicos.framework.core.facade.hibernate.AbstractSimpleCadEJBImpl#searchUnionLists(java.lang.String[], br.com.netservicos.framework.core.bean.Bean)
	 */
	@Override
	public Collection[] searchUnionLists(String[] queryName, Bean bean) {
		return super.searchUnionLists(queryName, bean);
	}
	
	/**
	 * @ejb.interface-method view-type="both"
 	 * @ejb.transaction type="Required" 
 	 * @ejb.permission unchecked="true"
	 * @see br.com.netservicos.framework.core.facade.hibernate.AbstractSimpleCadEJBImpl#searchMergeLists(java.lang.String[], br.com.netservicos.framework.core.bean.Bean)
	 */
	@Override
	public Collection[] searchMergeLists(String[] queryName, Bean filter) {
		return super.searchMergeLists(queryName, filter);
	}
}