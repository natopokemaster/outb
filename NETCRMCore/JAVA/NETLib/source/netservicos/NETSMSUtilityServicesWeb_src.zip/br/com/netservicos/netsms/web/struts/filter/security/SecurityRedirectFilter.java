package br.com.netservicos.netsms.web.struts.filter.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;

import br.com.netservicos.framework.web.BaseFilter;

/**
 * <P><B>Description :</B><BR>
 * Filter que verificar se no contexto de SSO foi acesada uma pagina
 * da aplica��o e o usuario nao est� devidamente autenticado.
 * Neste caso direciona para a pagina de login do IDP. Caso contrario
 * segue com o processamento dos outros filtros.
 * 
 * Para as aplica��es que utilizam SSO, este filtro deve ser configurado
 * no web.xml como primeiro na ordem dos filtros.
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Anton Vlassov
 * @since 29/07/2009
 */
public class SecurityRedirectFilter extends BaseFilter {

	private static final String PARAM_EXCLUDE_URI = "exclude";
	private static final String AUTHENTICATION_URI = "auth";
	
	private String [] exclude;
	private String auth;
	private FilterConfig filterConfig;
	
	public void destroy() {
	   this.exclude = null;
	   this.auth = null;

	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
	
		HttpServletRequest httpServletRequest = (HttpServletRequest)request;
		
		if (!ArrayUtils.contains(exclude,httpServletRequest.getServletPath())){
			  
			  // usuario nao autenticado solicitando uma pagina qualquer que nao seja a de lista de exclus�o
			  // redireciona para pagina de login, neste caso nao processa o chain de outros filtros, usuario nao autenticado
			  if( httpServletRequest.getUserPrincipal() == null) {
				   ((HttpServletResponse)response).sendRedirect(httpServletRequest.getContextPath()+auth);
				  return;
			  } else {
			  // usuario autenticado de dentro do circle of trust solicitando uma pagina qualquer sem ser pelo
			  // external login. Nesse caso, ele nao possui UserInfo setado na sessao. Pode ser feito um
			  // tratamento aqui, pois atualmente acaba caindo no ExpiredSessionFilter que verificar se h� sess�o
			  // e se h� user info na sess�o
			  // verificar se necessario um tratamento especifico ou redireciona para uma pagina de erro ou devolve
			  // para a url solicitante
				  filterChain.doFilter(request, response);
			  }
				
		} else {
			filterChain.doFilter(request, response);
		}

	}

	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
		this.exclude = getFormattedValues(filterConfig.getInitParameter(PARAM_EXCLUDE_URI));
		this.auth = filterConfig.getInitParameter(AUTHENTICATION_URI);

	}
	
}
