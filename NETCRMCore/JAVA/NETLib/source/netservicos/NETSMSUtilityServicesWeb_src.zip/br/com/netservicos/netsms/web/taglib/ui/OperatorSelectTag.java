/**
 * Created on 19/07/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: OperatorSelectTag.java,v 1.4 2007/08/14 23:21:31 morvimen Exp $
 */
package br.com.netservicos.netsms.web.taglib.ui;

import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.KEY_CURRENT_CID_CONTRATO;

import java.util.Arrays;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.StringUtils;

import br.com.netservicos.framework.core.bean.UserInfo;
import br.com.netservicos.framework.service.factory.ServiceFactory;
import br.com.netservicos.framework.service.factory.SourceLayerEnum;
import br.com.netservicos.framework.util.BaseConstants;
import br.com.netservicos.framework.util.loader.ApplicationLayer;
import br.com.netservicos.framework.util.loader.ApplicationResources;
import br.com.netservicos.netsms.utilities.operator.bean.OperatorDTO;
import br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService;

/**
 * <P><B>Description :</B><BR>
 * 	TODO descrever
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 19/07/2007
 * @version $Revision: 1.4 $
 */
public class OperatorSelectTag extends TagSupport {


	/**
	 * Serial Version
	 */
	private static final long serialVersionUID = 374773486571178524L;
	
	/**
	 * Tab space to be used for formating the taglib
	 */
	private static final char[] TAB_SPACE = new char[4];
	static {
		Arrays.fill(TAB_SPACE, ' ');
	}

	/**
	 * Default id of the select tag
	 */
	private static final String DEFAULT_ID 		= "cidContrato";
	/**
	 * Default name of the select tag
	 */
	private static final String DEFAULT_NAME 	= "cidContrato";
	/**
	 * Default role for the filter of the oeprators
	 */
	private static final String DEFAULT_ROLE	= "ACESSO";
	/**
	 * Default value of the default option
	 */
	private static final String DEFAULT_VALUE	= "0";
	/**
	 * Default text value of the default option
	 */
	private static final String DEFAULT_TEXT	= "Todos";
	/**
	 * Name of the hidden attribute that holds the name of the select
	 */
	public static final String ATTRIBUTE_OPERATOR_SELECT_NAME = "OPERATOR_SELECT_NAME";
	/**
	 * Name of the hidden attribute that holds the name of the action
	 */
	public static final String ATTRIBUTE_OPERATOR_SELECT_ACTION = "OPERATOR_SELECT_ACTION";
	/**
	 * Name of the hidden attribute that holds the text of the selected option
	 */
	public static final String ATTRIBUTE_OPERATOR_SELECTED_NAME = "OPERATOR_SELECTED_NAME";
	/**
	 * Key used to 'cache' de default operators
	 */
	private static final String NETSMS_DEFAULT_OPERADORAS_CACHED = "NETSMS_DEFAULT_OPERADORAS";

	/**
	 * Id of the select tag
	 */
	private String id;
	/**
	 * Name of the select option
	 */
	private String name;
	/**
	 * Role to be used to filter the operators
	 */
	private String role;
	/**
	 * The value of the default value
	 */
	private String defaultValue;
	/**
	 * The value of the default text
	 */
	private String defaultText;
	/**
	 * If the select tag should show a default value 
	 */
	private Boolean hasDefault = false;
	/**
	 * The action when the operator select is changed (event onchange)
	 */
	private String action;
	/**
	 * The id of the form in which this tag is embedded
	 */
	private String idForm;
	/**
	 * The id of the action parameter id
	 */
	private String actionParameterId;
	/**
	 * If the select is a multiple select, then this attribute represents the size
	 */
	private String multipleSize;

	/**
	 * 
	 * @see javax.servlet.jsp.tagext.TagSupport#doStartTag()
	 */
	@Override
	public int doStartTag() throws JspException {
		try {
			JspWriter writer = pageContext.getOut();
			writer.write(generateTag().toString());
			writer.flush();
			return SKIP_BODY;
		} catch (Exception ex) {
			throw new JspException(ex);
		}
	}
	
	
	private StringBuffer generateTag() {
		
		UserInfo userInfo = (UserInfo) super.pageContext.getSession().getAttribute(BaseConstants.ATRIBUTO_NET_SESSION_USER_INFO);
		
		Collection<OperatorDTO> operadoras = this.getOperators(userInfo);
		
		StringBuffer tagBuffer = new StringBuffer();
		
		if (StringUtils.isBlank(this.getMultipleSize())) {
		
			tagBuffer.append("<input type='hidden' name='");
			tagBuffer.append(ATTRIBUTE_OPERATOR_SELECT_NAME);
			tagBuffer.append("' value='");
			tagBuffer.append(this.getName());
			tagBuffer.append("' /> \n");
	
			tagBuffer.append("<input type='hidden' name='");
			tagBuffer.append(ATTRIBUTE_OPERATOR_SELECT_ACTION);
			tagBuffer.append("' value='");
			tagBuffer.append(this.getAction());
			tagBuffer.append("' /> \n");
	
			tagBuffer.append("<input type='hidden' id='");
			tagBuffer.append(ATTRIBUTE_OPERATOR_SELECTED_NAME);
			tagBuffer.append("' name='");
			tagBuffer.append(ATTRIBUTE_OPERATOR_SELECTED_NAME);
			tagBuffer.append("' value=''/> \n");

		}
		
		tagBuffer.append("<select name='");
		tagBuffer.append(this.getName());
		tagBuffer.append("' id='");
		tagBuffer.append(this.getId());
		tagBuffer.append("' ");

		if (StringUtils.isBlank(this.getMultipleSize())) {
			//Show the wait gif
			tagBuffer.append("onchange=showWaitGif();");
			
			//Change action of the page
			tagBuffer.append("document.getElementById('");
			tagBuffer.append(this.getIdForm());
			tagBuffer.append("').action='");
			tagBuffer.append(((HttpServletRequest)super.pageContext.getRequest()).getContextPath());
			tagBuffer.append("/changeOperator.do';");
	
			//Change the action parameter name to unspecified
			tagBuffer.append("document.getElementById('");
			tagBuffer.append(this.getActionParameterId());
			tagBuffer.append("').value='unspecified';");
	
			//Change the dbService hidden value name to unspecified
			tagBuffer.append("document.getElementById('dbService').value=this.options[this.options.selectedIndex].value.split('|')[0];");
			//Set the name of the operator selected
			tagBuffer.append("document.getElementById('");
			tagBuffer.append(ATTRIBUTE_OPERATOR_SELECTED_NAME);
			tagBuffer.append("').value=this.options[this.options.selectedIndex].text;");
			
			//Submit the page
			tagBuffer.append("document.getElementById('");
			tagBuffer.append(this.getIdForm());
			tagBuffer.append("').submit();");

			//Hide the wait gif
//			tagBuffer.append("hideWaitGif();");

		} else {
			tagBuffer.append(" multiple size=");
			tagBuffer.append(this.getMultipleSize());
		}
		tagBuffer.append(">\n");

		
		String currentCidContrato = userInfo.getProperties().getProperty(KEY_CURRENT_CID_CONTRATO);
		String currentDBService = userInfo.getCurrentDbService();

		StringBuffer options = new StringBuffer();

		Boolean foundSelected = Boolean.FALSE; 
		
		for (OperatorDTO operator : operadoras) {
			
			Boolean selected = Boolean.FALSE;
			String operatorDBService = operator.getDbService();
			String operatorCidContrato = operator.getCidContrato(); 
			String operatorName = operator.getNameOperator();
			
			if (operatorDBService.equals(currentDBService) && operatorCidContrato.equals(currentCidContrato)) {
				selected = Boolean.TRUE;
				foundSelected = selected;
			}
			options.append(generateOption(operatorCidContrato, operatorName, operatorDBService, selected));
		}
		
		if (this.isHasDefault()) {
			tagBuffer.append(generateOption(this.getDefaultValue(), this.getDefaultText(), "ALL", !foundSelected));
		}
		tagBuffer.append(options);
		
		tagBuffer.append("</select>");
		
		return tagBuffer;
		
	}


	private StringBuffer generateOption(Object value, Object text, String dbService, Boolean selected) {
		StringBuffer tagBuffer = new StringBuffer();
		tagBuffer.append(TAB_SPACE);
		tagBuffer.append("<option value='");
		tagBuffer.append(dbService);
		tagBuffer.append("|");
		tagBuffer.append(value);
		tagBuffer.append("'");
		if (selected) {
			tagBuffer.append(" selected ");
		}
		tagBuffer.append(">");
		tagBuffer.append(text);
		tagBuffer.append("</option>\n");
		return tagBuffer;
	}
	

	/**
	 * @since 07/08/2007
	 * @param userInfo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Collection<OperatorDTO> getOperators(UserInfo userInfo) {

		Collection operadoras = null;
		if (this.getRole().equals(DEFAULT_ROLE)) {
			operadoras = (Collection) pageContext.getSession().getAttribute(NETSMS_DEFAULT_OPERADORAS_CACHED);
		}
		
		if (operadoras == null || operadoras.size() < 1) {
			ApplicationResources applicationResources = 
					(ApplicationResources) pageContext.getServletContext().getAttribute(
							ApplicationResources.APPLICATION_RESOURCES_KEY);
			
			NETSMSSecurityService securityService = ServiceFactory.getService(
					NETSMSSecurityService.class, SourceLayerEnum.WEB, userInfo, 
					applicationResources.getLayers().get( 
							ApplicationLayer.WEB_LAYER ).getContextInstance(), true, true);
			operadoras = securityService.searchOperadorasParaUsuario(getRole());
			pageContext.getSession().setAttribute(NETSMS_DEFAULT_OPERADORAS_CACHED, operadoras);
		}
		
		return operadoras;
	}


	/**
	 * @return the id
	 */
	public String getId() {
		return StringUtils.isBlank(id) ? DEFAULT_ID : id ;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return StringUtils.isBlank(name) ? DEFAULT_NAME : name;
	}


	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the role
	 */
	public String getRole() {
		return StringUtils.isBlank(role) ? DEFAULT_ROLE : role;
	}


	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}


	/**
	 * @return the defaultValue
	 */
	public String getDefaultValue() {
		return StringUtils.isBlank(defaultValue) ? DEFAULT_VALUE : defaultValue;
	}


	/**
	 * @param defaultValue the defaultValue to set
	 */
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}


	/**
	 * @return the defaultText
	 */
	public String getDefaultText() {
		return StringUtils.isBlank(defaultText) ? DEFAULT_TEXT : defaultText;
	}


	/**
	 * @param defaultText the defaultText to set
	 */
	public void setDefaultText(String defaultText) {
		this.defaultText = defaultText;
	}


	/**
	 * @return the hasDefault
	 */
	public Boolean isHasDefault() {
		return hasDefault;
	}


	/**
	 * @param hasDefault the hasDefault to set
	 */
	public void setHasDefault(Boolean hasDefault) {
		this.hasDefault = hasDefault;
	}


	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}


	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}


	/**
	 * @return the idForm
	 */
	public String getIdForm() {
		return idForm;
	}


	/**
	 * @param idForm the idForm to set
	 */
	public void setIdForm(String idForm) {
		this.idForm = idForm;
	}


	/**
	 * @return the actionParameterId
	 */
	public String getActionParameterId() {
		return StringUtils.isBlank(actionParameterId) ? BaseConstants.ATRIBUTO_ACAO : actionParameterId;
	}


	/**
	 * @param actionParameterId the actionParameterId to set
	 */
	public void setActionParameterId(String actionParameterId) {
		this.actionParameterId = actionParameterId;
	}


	/**
	 * @return the multipleSize
	 */
	public String getMultipleSize() {
		return multipleSize;
	}


	/**
	 * @param multipleSize the multipleSize to set
	 */
	public void setMultipleSize(String multipleSize) {
		this.multipleSize = multipleSize;
	}

	
}
