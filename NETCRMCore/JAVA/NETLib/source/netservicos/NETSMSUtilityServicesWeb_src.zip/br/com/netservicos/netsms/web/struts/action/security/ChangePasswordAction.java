/**
 * Created on 27/05/2007
 * Project : NovoSMSWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 */
package br.com.netservicos.netsms.web.struts.action.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.netservicos.framework.ad.exception.InvalidUserPasswordException;
import br.com.netservicos.framework.ad.util.ADChangePassword;
import br.com.netservicos.framework.core.bean.DynamicBean;
import br.com.netservicos.framework.web.struts.action.SimpleCadAction;
import br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService;


/**
 * <P><B>Description :</B><BR>
 * 	Classe base respons�vel pela a��o de carga dos dados do usu�rio logado.
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Jonatas Piscirilo
 * @since 27/05/2007
 */
public class ChangePasswordAction extends SimpleCadAction {

	private static final Log log = LogFactory.getLog(ChangePasswordAction.class);
	private static final String SUCCESS_CHANGE_PASSWORD = "success_change_password";
	private static final String ERROR_CHANGE_PASSWORD = "error_change_password";
	
	
	public ActionForward savePassword(ActionMapping mapping, 
			   ActionForm form, 
			   HttpServletRequest request, 
			   HttpServletResponse response) throws Exception {
		
		DynamicBean bean = (DynamicBean) getWebBean(form);
		String userName = request.getUserPrincipal().getName();
		String actualPassword = (String)bean.get("actualPassword");
		String newPassword = (String)bean.get("newPassword");
		String retorno = "";
		
		try{
			NETSMSSecurityService securityService = getService(NETSMSSecurityService.class, request, Boolean.TRUE);
			securityService.changePassword(userName, actualPassword, newPassword);
			request.removeAttribute("senhaExpirada");
			ActionMessages messages = new ActionMessages();
			messages.add("Sucess", new ActionMessage("login.message.success.change.password"));
			super.addMessages(request, messages);
			request.getSession().removeAttribute("senhaExpirada");
			
		}catch(Exception e){
			ActionMessages errors = new ActionMessages();
			errors.add("Error", new ActionMessage("login.message.error.change.password" + e.getMessage()));
			super.addErrors(request, errors);
			throw e;
		}
		
		return mapping.findForward("change_password");				
		
	}
	
	
	public ActionForward redirectToChangePassword(ActionMapping mapping, 
			   ActionForm form, 
			   HttpServletRequest request, 
			   HttpServletResponse response) throws Exception {
		
		ActionMessages messages = new ActionMessages();
		messages.add("senhaExpirou", new ActionMessage("login.senhaexpiradawarning"));
		super.addMessages(request, messages);
		
		return mapping.findForward("change_password");
	}
		
	
	
	
	

	
	
	
}