//$Id: PropertyNotFoundException.java,v 1.1 2007/11/05 12:11:30 rmgray Exp $
package org.hibernate;

/**
 * Indicates that an expected getter or setter method could not be
 * found on a class.
 *
 * @author Gavin King
 */
public class PropertyNotFoundException extends MappingException {

	public PropertyNotFoundException(String s) {
		super(s);
	}

}






