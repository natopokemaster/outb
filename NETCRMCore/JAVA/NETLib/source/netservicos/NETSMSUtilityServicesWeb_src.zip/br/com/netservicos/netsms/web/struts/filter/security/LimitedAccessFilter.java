/**
 * Created on 29/10/2007
 * Project : NETModelWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: LimitedAccessFilter.java,v 1.1.2.2 2009/08/03 21:48:25 anvlassov Exp $
 */
package br.com.netservicos.netsms.web.struts.filter.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import br.com.netservicos.framework.web.BaseFilter;
import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTO_LIMITED_SYSTEM_ACCESS;

/**
 * <P><B>Description :</B><BR>
 * 	Used to determine if the user has 'limited access' to parts of the system.
 * Example - Ficha Financeiro, does not have access to the 'Menu Principal'
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 29/10/2007
 */
public class LimitedAccessFilter extends BaseFilter {
	
	private static final String AUTHENTICATION_URI = "auth";
	
	private String auth;

	/**
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		

		if (request instanceof HttpServletRequest) {
			
			HttpServletRequest servletRequest = (HttpServletRequest)request;
			
			// se o acesso � � pagina inicial do sistema, e eventualmente
			// um externalLogin foi realizado anteriormente, deve remover 
			// o flag de limita��o de acesso da sess�o
			if(servletRequest.getServletPath().equals(auth)) {
				if (servletRequest.getSession(Boolean.FALSE).getAttribute(ATTRIBUTO_LIMITED_SYSTEM_ACCESS)!= null) {
					servletRequest.getSession(Boolean.FALSE).removeAttribute(ATTRIBUTO_LIMITED_SYSTEM_ACCESS);
				}
			}
			
			// external login: se o flag de limita��o de acesso ainda n�o foi setado, efetua 
			if(!servletRequest.getServletPath().equals(auth)) {
				if (servletRequest.getSession(Boolean.FALSE).getAttribute(ATTRIBUTO_LIMITED_SYSTEM_ACCESS) == null) {
					servletRequest.getSession(Boolean.FALSE).setAttribute(ATTRIBUTO_LIMITED_SYSTEM_ACCESS, Boolean.TRUE);
				}
			}
		}
		
		filterChain.doFilter(request, response);
		
	}

	/**
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		this.auth = null;
	}

	/**
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		this.auth = filterConfig.getInitParameter(AUTHENTICATION_URI);
	}

}
