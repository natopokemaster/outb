/**
 * Created on 24/07/2007
 * Project : NETSMSUtilityCommon
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: OperatorDTO.java,v 1.1 2007/07/26 00:39:15 rmgray Exp $
 */
package br.com.netservicos.netsms.utilities.operator.bean;

import br.com.netservicos.framework.core.bean.BaseTransferObject;

/**
 * <P><B>Description :</B><BR>
 * 	DTO which represnts the basic information of a operator
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 24/07/2007
 * @version $Revision: 1.1 $
 */
public class OperatorDTO implements BaseTransferObject {

	/**
	 * Serial Version
	 */
	private static final long serialVersionUID = 5395336850808336096L;
	/**
	 * Database Service to which this operator belongs
	 */
	private String dbService;
	/**
	 * CidContrato to which this operator belongs
	 */
	private String cidContrato;
	
	/**
	 * Name of the operator
	 */
	private String nameOperator;
	
	/**
	 * @since 24/07/2007
	 * @param dbService
	 * @param cidContrato
	 */
	public OperatorDTO(String dbService, String cidContrato) {
		super();
		this.dbService = dbService;
		this.cidContrato = cidContrato;
	}
	/**
	 * @since 25/07/2007
	 * @param dbService
	 * @param cidContrato
	 * @param nameOperator
	 */
	public OperatorDTO(String dbService, String cidContrato, String nameOperator) {
		super();
		this.dbService = dbService;
		this.cidContrato = cidContrato;
		this.nameOperator = nameOperator;
	}
	/**
	 * @return the dbService
	 */
	public String getDbService() {
		return dbService;
	}
	/**
	 * @param dbService the dbService to set
	 */
	public void setDbService(String dbService) {
		this.dbService = dbService;
	}
	/**
	 * @return the cidContrato
	 */
	public String getCidContrato() {
		return cidContrato;
	}
	/**
	 * @param cidContrato the cidContrato to set
	 */
	public void setCidContrato(String cidContrato) {
		this.cidContrato = cidContrato;
	}
	/**
	 * @return the nameOperator
	 */
	public String getNameOperator() {
		return nameOperator;
	}
	/**
	 * @param nameOperator the nameOperator to set
	 */
	public void setNameOperator(String nameOperator) {
		this.nameOperator = nameOperator;
	}
	
	
	
}
