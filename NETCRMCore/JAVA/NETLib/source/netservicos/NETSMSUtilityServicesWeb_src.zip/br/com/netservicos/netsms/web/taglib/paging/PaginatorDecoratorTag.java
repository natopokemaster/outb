/**
 * Created on 11/07/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: PaginatorDecoratorTag.java,v 1.1 2007/07/26 01:12:29 rmgray Exp $
 */
package br.com.netservicos.netsms.web.taglib.paging;

import javax.servlet.http.HttpServletRequest;

import br.com.netservicos.framework.web.taglib.paging.PaginatorTag;

/**
 * <P><B>Description :</B><BR>
 * 	TODO descrever
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 11/07/2007
 * @version $Revision: 1.1 $
 */
public class PaginatorDecoratorTag extends PaginatorTag {

	/**
	 * Serial Version
	 */
	private static final long serialVersionUID = -7369199168168353631L;

	/**
	 * 
	 * @see br.com.netservicos.framework.web.taglib.paging.PaginatorTag#getHTMLNavigateBackward()
	 */
	@Override
	protected String getHTMLNavigateBackward() {
		
		return "<img src='" + createImageURL("bt_nav3.gif") + "'/>";
	}

	/**
	 * 
	 * @see br.com.netservicos.framework.web.taglib.paging.PaginatorTag#getHTMLNavigateEnd()
	 */
	@Override
	protected String getHTMLNavigateEnd() {
		return "<img src='" + createImageURL("bt_nav4.gif") + "'/>";
	}

	/**
	 * 
	 * @see br.com.netservicos.framework.web.taglib.paging.PaginatorTag#getHTMLNavigateForward()
	 */
	@Override
	protected String getHTMLNavigateForward() {
		return "<img src='" + createImageURL("bt_nav2.gif") + "'/>";
	}

	/**
	 * 
	 * @see br.com.netservicos.framework.web.taglib.paging.PaginatorTag#getHTMLNavigateStart()
	 */
	@Override
	protected String getHTMLNavigateStart() {
		return "<img src='" + createImageURL("bt_nav1.gif") + "'/>";
	}
	
	

	/**
	 * 
	 * @see br.com.netservicos.framework.web.taglib.paging.PaginatorTag#showInactiveLinks()
	 */
	@Override
	protected Boolean showInactiveLinks() {
		return Boolean.FALSE;
	}

	private String createImageURL(String imageName) {
		
		HttpServletRequest request = super.pageContext == null ? null : ((HttpServletRequest)super.pageContext.getRequest());
		
		return (request == null ? "" : request.getContextPath()) + "/common/imgs/" + imageName;
	}

	public static void main(String args[]) throws Exception {
		PaginatorTag tag = new PaginatorDecoratorTag();
		tag.test(1);
		tag.test(2);
		tag.test(3);
		tag.test(4);
		tag.test(5);
		tag.test(6);
		tag.test(7);
		tag.test(8);
		tag.test(9);
		tag.test(10);
		tag.test(11);
		tag.test(12);
	}
	
}
