//$Id: MySQLMyISAMDialect.java,v 1.1 2007/11/05 12:11:28 rmgray Exp $
package org.hibernate.dialect;

/**
 * @author Gavin King
 */
public class MySQLMyISAMDialect extends MySQLDialect {

	public String getTableTypeString() {
		return " type=MyISAM";
	}

	public boolean dropConstraints() {
		return false;
	}

}
