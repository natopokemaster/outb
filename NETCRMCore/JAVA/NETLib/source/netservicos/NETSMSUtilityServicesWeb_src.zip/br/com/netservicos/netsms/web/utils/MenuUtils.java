/**
 * Created on 23/07/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: MenuUtils.java,v 1.1 2007/07/26 00:41:36 rmgray Exp $
 */
package br.com.netservicos.netsms.web.utils;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import br.com.netservicos.framework.util.reflection.ReflectionUtil;

/**
 * <P><B>Description :</B><BR>
 * 	TODO descrever
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 23/07/2007
 * @version $Revision: 1.1 $
 */
public class MenuUtils {

	/**
	 * 
	 * @since 29/06/2007
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Map<String, Object>> getPrincipalMenu(HttpServletRequest request) {
		return (Map) ReflectionUtil.invokeMethod("getMenu", 
				new Class[]{}, 
				new Object[]{}, 
				request.getUserPrincipal(), 
				request.getUserPrincipal().getClass());
	}
	
}
