/**
 * Created on 31/05/2007
 * Project : NETSMSUtilityServices
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: GrupoAcaoEnum.java,v 1.1 2007/07/26 00:35:25 rmgray Exp $
 */
package br.com.netservicos.netsms.utilities.auditoria.types;

import java.io.Serializable;

/**
 * <P><B>Description :</B><BR>
 * 	Representa a classifica��o de uma a��o
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Morgany
 * @since 31/05/2007
 * @version $Revision: 1.1 $
 */
public enum GrupoAcaoEnum implements Serializable{

	CADASTRO,
	ACESSO,
	APROVISIONAR,
	FATURAR,
	ATENDER,
	INSTALAR,
	VENDER,
	PERFIL_DE_ACESSO,
	ADMINISTRATIVO;
}
