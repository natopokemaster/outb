//$Id: PreLoadEventListener.java,v 1.1 2007/11/05 12:11:30 rmgray Exp $
package org.hibernate.event;

import java.io.Serializable;

/**
 * Called before injecting property values into a newly 
 * loaded entity instance.
 *
 * @author Gavin King
 */
public interface PreLoadEventListener extends Serializable {
	public void onPreLoad(PreLoadEvent event);
}
