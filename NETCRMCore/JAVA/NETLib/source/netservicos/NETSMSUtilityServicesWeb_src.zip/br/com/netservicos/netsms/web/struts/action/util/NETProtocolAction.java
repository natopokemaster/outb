package br.com.netservicos.netsms.web.struts.action.util;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.netservicos.framework.core.bean.UserInfo;

import static br.com.netservicos.framework.service.webservice.header.Atendimento.ATENDIMENTO;
import br.com.netservicos.framework.service.webservice.header.Atendimento;

import br.com.netservicos.framework.web.struts.action.SimpleCadAction;


public class NETProtocolAction extends SimpleCadAction {
	
	
	private static final Log log = LogFactory.getLog(NETProtocolAction.class);
	
	/***
	 * Valida a exist�ncia de um contato de atendimento na sess�o usuario
	 * @param session
	 * @return Boolean
	 */
	public Boolean existsAtendimento(HttpSession session){
		Boolean exists = Boolean.FALSE;
		UserInfo userInfo = super.getUserInfo(session);
		if(userInfo!=null){
			if(userInfo.getProperties().containsKey(ATENDIMENTO)){
				return Boolean.TRUE;
			}else{
				return Boolean.FALSE;
			}
		}else{
			log.warn("N�o foi possivel setar as informa��es de contato na sess�o do usu�rio");
		}
		return exists;
	} 
	
	
	/**
	 * Seta as informa��es de contato na sess�o do usu�rio
	 * @param session
	 * @param contato
	 * @return void
	 */
	public void setAtendimento(HttpSession session, Atendimento atendimento){
		UserInfo userInfo = super.getUserInfo(session);
		if(userInfo!=null){
			if(userInfo.getProperties().containsKey(ATENDIMENTO)){
				userInfo.getProperties().remove(ATENDIMENTO);
			}
			userInfo.getProperties().put(ATENDIMENTO, atendimento);
		}
	}
	
	
	/***
	 * Limpa informa��es de contato da sess�o do usu�rio
	 * @param session
	 * @param contato
	 * @return void
	 */
	public void clearAtendimento(HttpSession session){
		UserInfo userInfo = super.getUserInfo(session);
		if(userInfo!=null){
			if(userInfo.getProperties().containsKey(ATENDIMENTO)){
				userInfo.getProperties().remove(ATENDIMENTO);
			}
		}
	}
	
	/***
	 * 
	 * @param session
	 * @return {@link br.com.netservicos.framework.service.webservice.header.Atendimento}
	 */
	public Atendimento getAtendimento(HttpSession session){
		Atendimento atendimento = null;
		UserInfo userInfo = super.getUserInfo(session);
		if(userInfo!=null){
			if(userInfo.getProperties().containsKey(ATENDIMENTO)){
				atendimento = (Atendimento) userInfo.getProperties().get(ATENDIMENTO);
			}
		}else{
			log.warn("N�o foi possivel setar as informa��es de contato na sess�o do usu�rio");
		}	
		return atendimento;
	}
		
	
}
