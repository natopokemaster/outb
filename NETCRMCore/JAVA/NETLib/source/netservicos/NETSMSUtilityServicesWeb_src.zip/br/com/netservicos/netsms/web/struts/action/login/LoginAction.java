/**
 * Created on 27/05/2007
 * Project : NovoSMSWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 */
package br.com.netservicos.netsms.web.struts.action.login;

import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTE_MENU;
import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTO_PREFIXO_DBSERVICE;
import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTO_PREFIXO_DBSERVICE_PER_APPLICATION;

import java.security.Principal;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.netservicos.framework.auth.util.jaas.BaseUser;
import br.com.netservicos.framework.auth.util.jaas.SecurityParametersEnum;
import br.com.netservicos.framework.core.bean.UserInfo;
import br.com.netservicos.framework.core.bean.UserInfoImpl;
import br.com.netservicos.framework.core.dao.DBService;
import br.com.netservicos.framework.util.BaseConstants;
import br.com.netservicos.framework.util.context.Context;
import br.com.netservicos.framework.util.loader.ApplicationLayer;
import br.com.netservicos.framework.util.loader.ApplicationResources;
import br.com.netservicos.framework.util.reflection.ReflectionUtil;
import br.com.netservicos.framework.web.authentication.Authentication;
import br.com.netservicos.framework.web.authentication.AuthenticationFactory;
import br.com.netservicos.framework.web.struts.action.SimpleCadAction;
import br.com.netservicos.netsms.utilities.auditoria.NETSMSLogAuditoria;
import br.com.netservicos.netsms.utilities.auditoria.NETSMSLogAuditoriaClient;
import br.com.netservicos.netsms.utilities.auditoria.types.AcaoEnum;
import br.com.netservicos.netsms.utilities.auditoria.types.CriticidadeEnum;
import br.com.netservicos.netsms.web.utils.MenuUtils;

/**
 * <P><B>Description :</B><BR>
 * 	Classe base respons�vel pela a��o de carga dos dados do usu�rio logado.
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Morgany
 * @since 27/05/2007
 */
public abstract class LoginAction extends SimpleCadAction {


	private static final Log log = LogFactory.getLog(LoginAction.class);
	
//	private static final String GUEST = "guest";
	private static final String HOSTNAME = "hostname";
	private static final String IP_ADDRESS = "ipAddress";
	/**
	 * Key which represents the database in which the user was authenticated
	 */
//	private static final String IDENTITY_BASE = "identityBase";
	/**
	 * Key which represents the system where the user logged onto 
	 */
//	private static final String IDENTITY_SYSTEM = "identitySystem";
	/**
	 * Key which represents the applciation where the user logged onto 
	 */
//	private static final String IDENTITY_APPLICATION = "identityApplication";

	
//	private static final String PASSWORD_EXPIRED = "passwordExpired";
	private static final String PROCESS_LOGIN = "processLogin";
	private static final String PROCESS_LOGOUT = "processLogout";
//	private static final String PROCESS_CHANGE_PASSWORD = "change_password";
	
	
	
	protected abstract String getPrefixoDatabaseService();
	
	protected abstract void configureApplicationUserInfo(UserInfo userInfo, HttpServletRequest request);
	
	/**
	 * 
	 * @see br.com.netservicos.framework.web.struts.action.SimpleCadAction#prepareSearch(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public ActionForward prepareSearch(final ActionMapping mapping, final ActionForm form,
			final HttpServletRequest request, final HttpServletResponse response)
			throws Exception {
		
		final UserInfo fakeUserInfo = this.createBasicUserInfo(request);
		ActionForward forward = null;
		
		// FIXME extrair adapter para criar principal a partir de informacoes do UserInfo
		
//		if (fakeUserInfo.getSelectedDbServices() != null && fakeUserInfo.getSelectedDbServices().length > 0) {
//			fakeUserInfo.setCurrentDbService(fakeUserInfo.getSelectedDbServices()[0]);
//		}
		request.getSession().setAttribute(BaseConstants.ATRIBUTO_NET_SESSION_USER_INFO, fakeUserInfo);
		forward = super.prepareSearch(mapping, form, request, response);
		
//		String[] dbServices = fakeUserInfo.getSelectedDbServices();
//		for (int i = 0; i < dbServices.length; i++) {
//			try {
//				if (log.isDebugEnabled()) {
//					log.debug("Utilizing the database service : " + dbServices[i] + 
//							" to perform the prepareSearch function of the login action.");
//				}
//
//				fakeUserInfo.setCurrentDbService(dbServices[i]);
//				forward = super.prepareSearch(mapping, form, request, response);
//			} catch (Exception ignoreException) {
//				if (log.isDebugEnabled()) {
//					log.debug("Error utilizing the database service : " + dbServices[i] + 
//							" to perform the prepareSearch function of the login action.", ignoreException);
//				}
//			}
//			
//		}
		
		
		
		request.getSession().removeAttribute(BaseConstants.ATRIBUTO_NET_SESSION_USER_INFO);
		
		return forward;
	}
	
	

	/**
	 * @see org.apache.struts.actions.DispatchAction
	 * 
	 * Acesso a partir de uma aplica��o externa.
	 * 
	 * Parametros obrigatorios:
	 *   j_url : informa a pagina que est� sendo solicitada, a a��o e os parametros
	 *        Ex: j_url=/equipamentos/manterArea.do?acao=prepareSearch&param1=123 
	 *  
	 *   j_username:  nome do usuario com o qual ser� feita autentica��o
	 *   j_password: senha, criptografado ou n�o com a qual o usuario ser� autenticado (ver Parametro Opcional)
	 *   j_identity_base: nome da base NETSMS no qual usuario ser� validado atraves do sistema PERFIL. Ex: ddabc02f
	 *   j_system: identifcica��o do sistema no qual ser� feita a autentica��o.
	 *  
	 * Parametro opcional:
	 *   j_password_secure, dominio={true,false}.
	 *   Caso "true", informa que a senha est� criptografada, assim o algoritmo
	 *   apropriado ser� utilziado para decriptografar 
	 * 
	 */
	public ActionForward externalLogin(ActionMapping mapping, 
			   ActionForm form, 
			   HttpServletRequest request, 
			   HttpServletResponse response) throws Exception {
		
		
		//Forcar invalidar o sess�o de usuario e criar um nova sess�o
		processLogout(mapping, form, request, response);
		request.getSession(true);
		
		ActionForward actionForward = null;
		
		if (request.getParameter(SecurityParametersEnum.IDENTIFICATION_URL.identifier) != null
				&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_USERNAME.identifier) != null
				&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_PASSWORD.identifier) != null
				&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_DATABASE.identifier) != null
				&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_SYSTEM.identifier) != null ) {
			
			Authentication authentication = AuthenticationFactory.getInstance().getDefaultAuthentication();
			
			if ( authentication.authenticate( request, 
					request.getParameter(SecurityParametersEnum.IDENTIFICATION_USERNAME.identifier), 
					request.getParameter(SecurityParametersEnum.IDENTIFICATION_PASSWORD.identifier).toCharArray(),
					Boolean.valueOf(request.getParameter(SecurityParametersEnum.IDENTIFICATION_PASSWORD_SECURE.identifier)))  ) {
			
				request.getSession().setAttribute("ACESSO_EXTERNAL_LOGIN", Boolean.TRUE);
				processLogin(mapping, form, request, response);
				
				request.getRequestDispatcher(request.getParameter(SecurityParametersEnum.IDENTIFICATION_URL.identifier)).forward(
						request, response);
				
			} else {
				// N�O AUTORIZADO envia c�digo de status 403
				response.sendError( HttpServletResponse.SC_UNAUTHORIZED );
			}
			
		} else {
			// PROIBIDO envia c�digo de status 401
			response.sendError( HttpServletResponse.SC_FORBIDDEN );
		}
		
		return actionForward;
	}
	
	
	/**
	 * @see org.apache.struts.actions.DispatchAction
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public final ActionForward processLogin(ActionMapping mapping, 
							   ActionForm form, 
							   HttpServletRequest request, 
							   HttpServletResponse response) throws Exception {
		
		boolean isDebugEnabled = log.isDebugEnabled();
		
		// Criando o objeto representante do usu�rio logado
		UserInfo userInfo = configureUserInfo( request );
		
		if (isDebugEnabled) {
			log.debug("Starting the processing of 'processLogin' action");
		}
		
		if (validatePasswordExpiration(request, mapping)) {
			return mapping.findForward("change_password");
		}
		
		
		// efetua log de auditoria
		NETSMSLogAuditoria logAuditoria = new NETSMSLogAuditoria();
		
		// Obtem o sistema ( da config de spring ), pois no Principal com provider pode
		// ser configurado acesso a dois sistemas diferentes
		String systemName = this.getApplicationResources().getIdentifierSystem();
		
		String applicationName = userInfo.getProperties().getProperty(SecurityParametersEnum.IDENTIFICATION_APPLICATION.identifier);
		if(applicationName == null ) {
			applicationName = this.getApplicationResources().getIdentifierApplication();
		}
		
		logAuditoria.setSistema( applicationName );
		logAuditoria.setAcao( AcaoEnum.LOGIN_OK );
		logAuditoria.setCriticidade( CriticidadeEnum.MEDIA );
		logAuditoria.setUsuario( request.getUserPrincipal().getName() );
		logAuditoria.setCidade( userInfo.getCurrentDbService() ); 
		logAuditoria.setNota("LOGIN --> SYSTEM : " + systemName + " APPLICATION --> : " + applicationName);
		
		NETSMSLogAuditoriaClient.getInstance().sendLogAuditoria( 
				logAuditoria, userInfo.getCurrentDbService() );
		
		// Retornando sucesso no processamento da action de login
		return mapping.findForward(PREFIX_SUCCESS + PROCESS_LOGIN);
	}
	
	/**
	 * Verifica se a senah do usuario expirou e est� prestes a expirar. Em caso
	 * positivo configura parametros essenciais no request e retorna "true"
	 * para que seja efetuado forward para p�gina apropriada
	 * @since 24/07/2009
	 * @param request
	 * @param mapping
	 * @return
	 */
	protected boolean validatePasswordExpiration( HttpServletRequest request, ActionMapping mapping ){
		
		String passwordExpired = getPrincipalProperty(SecurityParametersEnum.USER_PASSWORD_EXPIRED.identifier, request);
		if (passwordExpired != null && passwordExpired.equals("true")) {
			request.setAttribute(ATRIBUTO_SENHA_EXPIRADA, true);
			request.getSession().setAttribute(ATRIBUTO_SENHA_EXPIRADA, true);
			ActionMessages messages = new ActionMessages();
			messages.add("senhaExpirou", new ActionMessage("login.senhaexpiradawarning"));
			super.addMessages(request, messages);
			return true;
		}
		
		return false;
	}
	
	
	/**
	 * Configura o objeto userInfo existente na sess�o do usu�rio, com as informa��es 
	 * de acesso confirmadas, ap�s efetuar o processo de login OK.<br>
	 * Al�m disto, verifica quais s�o as bases dispon�veis atuais da aplica��o e configura,
	 * para o usu�rio somente estas bases ativas.
	 * @param request HttpServletRequest com o objeto representando o request efetuado.
	 * @return UserInfo com o objeto userInfo configurado corretamente.
	 * @throws Exception com a exce��o demonstrativa do erro, caso ocorra
	 * 
	 * @author Ricardo Limonta
	 * @since 28/09/2005
	 */
	protected final UserInfo configureUserInfo(HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		
		UserInfo userInfo = getUserInfo(session);
		
		if (userInfo == null) {
			userInfo = createUserInfo(request);
		}
        return userInfo;
	}
	
	/**
	 * Metodo responsavel por criar e configurar inicialmente o objeto UserInfo.
	 * @param request HttpServletRequest com o objeto que representa a request web.
	 * @return UserInfo com a instancia do objeto criado e configurado.
	 * 
	 * @author Rodrigo Silva
	 * @since 29/01/2007
	 */
	@SuppressWarnings("unchecked")
	protected  UserInfo createUserInfo(HttpServletRequest request) {
		
		//Criar o user info basico 
		UserInfo userInfo = this.createBasicUserInfo(request);
				
		StringBuffer requestURL = request.getRequestURL(); 
		String contextPath = request.getContextPath();
		
		String urlAndContext  = requestURL.substring(0, requestURL.indexOf(contextPath) + 1 );
			   urlAndContext += contextPath.substring(1, contextPath.length());
			   
	    getPrincipalProperties(request.getUserPrincipal()).setProperty(URL_AND_CONTEXT_WEBAPP, urlAndContext);
	    
	    ApplicationResources resources = getApplicationResources();
	    getPrincipalProperties(request.getUserPrincipal()).setProperty(IDENTIFIER_APPLICATION_ID_INICIAL, resources.getApplicationIdentifier());
								
		//Seta base atual
		Properties principalProperties = this.getPrincipalProperties(request.getUserPrincipal());
		String databaseIdentity = principalProperties.getProperty(SecurityParametersEnum.IDENTIFICATION_DATABASE.identifier);
		String prefixoDBService = this.getPrefixoDatabaseService();
		
		userInfo.setProperties(principalProperties);
		
		String currentDBService = prefixoDBService + databaseIdentity;
		if (!ArrayUtils.contains(userInfo.getSelectedDbServices(), currentDBService)) {
			
			for (int i = 0; i < userInfo.getSelectedDbServices().length; i++) {
				String configuredDBService = userInfo.getSelectedDbServices()[i];
				if (configuredDBService.equalsIgnoreCase(currentDBService)) {
					currentDBService = configuredDBService;
					break;
				}
			}
		}
		
	
		userInfo.setCurrentDbService(currentDBService);
		getPrincipalProperties(request.getUserPrincipal()).setProperty(BaseConstants.CURRENT_DB_SERVICE, userInfo.getCurrentDbService());
		
		userInfo.getProperties().setProperty(ATTRIBUTO_PREFIXO_DBSERVICE, prefixoDBService);
		
		// Inicio : guardar os database prefxies por application
		Hashtable<String, String> applicationDatabasePrefixes = (Hashtable<String, String>) userInfo.getProperties().get(ATTRIBUTO_PREFIXO_DBSERVICE_PER_APPLICATION);
		if (applicationDatabasePrefixes == null) {
			applicationDatabasePrefixes = new Hashtable<String, String>();
		}
		applicationDatabasePrefixes.put(resources.getApplicationIdentifier(), prefixoDBService);
		userInfo.getProperties().put(ATTRIBUTO_PREFIXO_DBSERVICE_PER_APPLICATION, applicationDatabasePrefixes);
		// Fim : guardar os database prefxies por application
		
		// obtem informacoes do usuario 
		this.configureApplicationUserInfo(userInfo, request);
		
		userInfo.setUserId(request.getUserPrincipal().getName());
        request.getSession().setAttribute(BaseConstants.ATRIBUTO_NET_SESSION_USER_INFO, userInfo);
        
        // configura informa��es adicionais do usuario - userinfo ja setada no request para DelegateService
        userInfo.setUserInformations(getBaseUser(request));
        request.getSession().setAttribute(BaseConstants.ATRIBUTO_NET_SESSION_USER_INFO, userInfo);
        request.getSession().setAttribute(ATTRIBUTE_MENU, getMenu(request));
		
		return userInfo;
	}
	
	/**
	 * Obtem o menu. Implementado como protected para poder ser customizado pelas calsses filhas
	 * @since 23/07/2009
	 * @param request
	 * @return
	 */
	protected Object getMenu(HttpServletRequest request) {
		return MenuUtils.getPrincipalMenu(request);
	}
	
	
	/**
	 * Criar o UserInfo basico, sem necessidade de usuario esta logado no sistema
	 * @since 19/07/2007
	 * @param request {@link HttpServletRequest} de usuario
	 * @return UserInfo com a instancia do objeto criado e configurado.
	 */
	@SuppressWarnings("unchecked")
	private UserInfo createBasicUserInfo(HttpServletRequest request) {
		
		ApplicationResources resources = getApplicationResources();
		UserInfo userInfo = null;
		Context context;
		String[] dbServices;
		ApplicationLayer layer;
		
		if (request.getUserPrincipal() == null) {
			userInfo = new UserInfoImpl();
		} else {
    		userInfo = new UserInfoImpl(request.getUserPrincipal(),
    				getPrincipalProperties(request.getUserPrincipal()));
    	
    		
		}
		if (resources != null) {
			layer = resources.getLayers().get(ApplicationLayer.WEB_LAYER);
			
			if (layer != null) {
				
				context = layer.getContextInstance();
				dbServices = (String[]) context.lookup(BaseConstants.PROP_DB_SERVICES);
				Map<String, Boolean> dbServicesActive = (Map<String, Boolean>) context.lookup(BaseConstants.PROP_DB_SERVICES_ACTIVE);
				
				dbServices = DBService.getDBServicesActive(dbServices, dbServicesActive);
				
				if (dbServices != null && dbServices.length > 0) {
				    
					userInfo.setSelectedDbServices(dbServices);
					
					request.getSession().setAttribute(BaseConstants.PROP_DB_SERVICES, dbServices);
				} else {
			    	userInfo.setCurrentDbService(null);
			    	userInfo.setSelectedDbServices(null);
			    }
				
				if( resources.getDaoFactory() != null && resources.getDelegate() != null ) {
					
    				userInfo.getProperties().put(BaseConstants.DELEGATE_NAME,
    						resources.getDelegate().getName());
    				userInfo.getProperties().put(BaseConstants.DAOFACTORY_NAME,
    						resources.getDaoFactory().getName());
				}
			}
		}
		
		userInfo.setUserSessionId(request.getSession().getId());
		
        userInfo.getProperties().put(HOSTNAME, request.getRemoteHost());
        userInfo.getProperties().put(IP_ADDRESS, request.getRemoteAddr());
        
        userInfo.setCurrentSystemIdentifier(resources.getIdentifierSystem());
        userInfo.setCurrentApplicationIdentifier(resources.getIdentifierApplication());

		return userInfo;
		
	}
	
	/**
	 * Efetua logou, eliminando o Prinicipal
	 * TODO: adaptar para SLO
	 * @since 30/07/2009
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward processLogout(ActionMapping mapping, 
							   ActionForm form, 
							   HttpServletRequest request, 
							   HttpServletResponse response) throws Exception {

		Authentication authentication = AuthenticationFactory.getInstance().getDefaultAuthentication();
		authentication.logout(request);
		
		return mapping.findForward(PREFIX_SUCCESS + PROCESS_LOGOUT);
	}
	
	
	protected String getPrincipalProperty(String propertyName, HttpServletRequest request) {
		
		Properties principalProperties = this.getPrincipalProperties(request.getUserPrincipal());
		String property = null;
		
		if (principalProperties != null) {
			property = principalProperties.getProperty(propertyName);
		}
		
		return property;
		
	}
	
	
	protected Properties getPrincipalProperties(Principal principal) {
		
		Properties result;
		try{
    		result = (Properties) ReflectionUtil.invokeMethod("getProperties", 
    				new Class[]{}, new Object[]{}, 
    				principal, principal.getClass());
		}catch (Exception e) {
			result = null;
		}
		return result;
	}
	
	/**
	 * Recupera as informa��es do usuario do Principal
	 * @since 24/07/2009
	 * @param request
	 * @return
	 */
	protected BaseUser getBaseUser(HttpServletRequest request){
		Principal principal = request.getUserPrincipal();
		BaseUser result;
		try{
    		result = (BaseUser) ReflectionUtil.invokeMethod("getBaseUser", 
    				new Class[]{}, new Object[]{}, 
    				principal, principal.getClass());
		}catch (Exception e) {
			result = null;
		}
		return result;
		
	}
	
	
	
}