package br.com.netservicos.netsms.web.struts.filter.security;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.netservicos.framework.auth.util.jaas.SecurityParametersEnum;
import br.com.netservicos.framework.web.BaseFilter;

/**
 * 
 * <P><B>Description :</B><BR>
 * Trata o caso de External Login, quando este � efetuado a partir de algum sistema legado
 * que n�o est� embaixo do NetFramework, como VB e efetua tentativa de acesso atraves
 * de POST de parametros de autentica��o.
 * 
 * Intercepta esta ocorrencia e monta um query string de redirect que pdoe ser compreendido,
 * e envia para a URI a ser interceptada pelas configura��es do weblogic,
 * e ser solicitado a autentica��o para ITS
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Anton Vlassov
 * @since 24/08/2009
 */
public class ExternalLoginFilter extends BaseFilter {
    
private static final String PARAM_EXTERNAL_LOGIN_URI = "externalLogin";
	
	private String externalLogin;
	private FilterConfig filterConfig;
	
	public void destroy() {
		this.externalLogin = null;
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		
		if(request instanceof HttpServletRequest) {
			HttpServletRequest httpServletRequest = (HttpServletRequest)request;
			HttpServletResponse httpServletResponse = (HttpServletResponse)response;
			
			if (request.getParameter(SecurityParametersEnum.IDENTIFICATION_URL.identifier) != null
					&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_USERNAME.identifier) != null
					&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_PASSWORD.identifier) != null
					&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_DATABASE.identifier) != null ) {
				
				/**httpServletResponse.sendRedirect(
						    httpServletResponse.encodeRedirectURL(
						    		buildRedirectString(httpServletRequest)));
						    		*/
				httpServletResponse.sendRedirect(buildRedirectString(httpServletRequest));
				
				
			} else {
				httpServletResponse.sendError( HttpServletResponse.SC_UNAUTHORIZED );
			}
		}
		
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		this.externalLogin = filterConfig.getInitParameter(PARAM_EXTERNAL_LOGIN_URI);
	}
	
	/**
	 * Monta a string de parametros a serem repassados de uma aplica��o para outra,
	 * @since 21/08/2009
	 * @param httpServletRequest
	 * @return
	 */
	private String buildRedirectString(HttpServletRequest httpServletRequest) {
		StringBuilder redirect = new StringBuilder();
		redirect.append(httpServletRequest.getContextPath()+this.externalLogin);
		
		// repassa todos os  parameters encontrados
		Enumeration <String> parameters = httpServletRequest.getParameterNames();
		if(parameters != null) {
			while (parameters.hasMoreElements()) {
				String paramName = parameters.nextElement();
				redirect.append(buildAppend(paramName, httpServletRequest));
				/**if(SecurityParametersEnum.isSecurityParameter(paramName)) {
					redirect.append(buildAppend(paramName, httpServletRequest));
				}*/
			}
		}
		
		return redirect.toString().replaceFirst("&", "?");
	}
	
	/**
     * Constroe um parametro a ser concatenado no query string no formato
     * "&paramName=paramValue"
     * @since 06/08/2009
     * @param paramName
     * @param request
     * @return
     */
    private String buildAppend(String paramName, HttpServletRequest request ) {
    	return new StringBuilder().append("&")
								 .append(paramName)
								 .append("=")
								 .append(request.getParameter(paramName)).toString();
    }

}
