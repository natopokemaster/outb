package br.com.netservicos.netsms.utilities.auditoria;


import java.io.Serializable;

import br.com.netservicos.netsms.utilities.auditoria.types.AcaoEnum;
import br.com.netservicos.netsms.utilities.auditoria.types.CriticidadeEnum;

/**
 * <P><B>Description :</B><BR>
 * 	Bean which describes the items that need to be logged to the auditor 
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author rmgray
 * @since 28/05/2007
 * @version $Revision: 1.2 $
 */
public class NETSMSLogAuditoria implements Serializable {


	/**
	 * Serial Version
	 */
	private static final long serialVersionUID = 7878321092324729203L;
	
	/**
	 * Nome de sistema eg.NOVOSMS, NETSMS, ATLAS etc.
	 */
	private String sistema;
	/**
	 * Login de usuario
	 */
	private String usuario;
	/**
	 * CriticidadeEnum de mensagen de LOG, ver tabela TBLOG_CRITICIDADE
	 */
	private CriticidadeEnum criticidade;
	/**
	 * A��o de mensagen de LOG, ver tabela TBLOG_ACAO
	 */
	private AcaoEnum acao;
	/**
	 * Cidade aonde o usuario esta fazendo o transa��o, S�o paulo, Rio de Janeiro, Porto alegre etc..
	 */
	private String cidade;
	/**
	 * Essa � a tabela. campo que foi alterado, geralmente a chave da tabela. ou o ID da tabela
	 */
	private String campo;
	/**
	 * O registro realmente que teve impacto por exemplo o ID_ITEM_EXTRATO que foi alterado
	 */
	private String idRegistro;
	/**
	 * Campo de Obs geralmente o que aconteceu com o registro : INSERT/UPDATE/DELETE
	 */
	private String nota;
	
	
	/**
	 * @since 28/05/2007
	 */
	public NETSMSLogAuditoria() {
		super();
	}


	/**
	 * @since 28/05/2007
	 * @param sistema
	 * @param usuario
	 * @param criticidade
	 * @param acao
	 * @param cidade
	 * @param campo
	 * @param idRegistro
	 * @param nota
	 */
	public NETSMSLogAuditoria(String sistema, String usuario, CriticidadeEnum criticidade, 
			AcaoEnum acao, String cidade, String campo, String idRegistro, String nota) {
		super();
		this.sistema = sistema;
		this.usuario = usuario;
		this.criticidade = criticidade;
		this.acao = acao;
		this.cidade = cidade;
		this.campo = campo;
		this.idRegistro = idRegistro;
		this.nota = nota;
	}


	/**
	 * @return the acao
	 */
	public AcaoEnum getAcao() {
		return acao;
	}


	/**
	 * @param acao the acao to set
	 */
	public void setAcao(AcaoEnum acao) {
		this.acao = acao;
	}


	/**
	 * @return the campo
	 */
	public String getCampo() {
		return campo;
	}


	/**
	 * @param campo the campo to set
	 */
	public void setCampo(String campo) {
		this.campo = campo;
	}


	/**
	 * @return the cidade
	 */
	public String getCidade() {
		return cidade;
	}


	/**
	 * @param cidade the cidade to set
	 */
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}


	/**
	 * @return the criticidade
	 */
	public CriticidadeEnum getCriticidade() {
		return criticidade;
	}


	/**
	 * @param criticidade the criticidade to set
	 */
	public void setCriticidade(CriticidadeEnum criticidade) {
		this.criticidade = criticidade;
	}


	/**
	 * @return the idRegistro
	 */
	public String getIdRegistro() {
		return idRegistro;
	}


	/**
	 * @param idRegistro the idRegistro to set
	 */
	public void setIdRegistro(String idRegistro) {
		this.idRegistro = idRegistro;
	}


	/**
	 * @return the nota
	 */
	public String getNota() {
		return nota;
	}


	/**
	 * @param nota the nota to set
	 */
	public void setNota(String nota) {
		this.nota = nota;
	}


	/**
	 * @return the sistema
	 */
	public String getSistema() {
		return sistema;
	}


	/**
	 * @param sistema the sistema to set
	 */
	public void setSistema(String sistema) {
		this.sistema = sistema;
	}


	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}


	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}


	/**
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((acao == null) ? 0 : acao.hashCode());
		result = PRIME * result + ((campo == null) ? 0 : campo.hashCode());
		result = PRIME * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = PRIME * result + ((criticidade == null) ? 0 : criticidade.hashCode());
		result = PRIME * result + ((idRegistro == null) ? 0 : idRegistro.hashCode());
		result = PRIME * result + ((nota == null) ? 0 : nota.hashCode());
		result = PRIME * result + ((sistema == null) ? 0 : sistema.hashCode());
		result = PRIME * result + ((usuario == null) ? 0 : usuario.hashCode());
		return result;
	}


	/**
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final NETSMSLogAuditoria other = (NETSMSLogAuditoria) obj;
		if (acao == null) {
			if (other.acao != null)
				return false;
		} else if (!acao.equals(other.acao))
			return false;
		if (campo == null) {
			if (other.campo != null)
				return false;
		} else if (!campo.equals(other.campo))
			return false;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (criticidade == null) {
			if (other.criticidade != null)
				return false;
		} else if (!criticidade.equals(other.criticidade))
			return false;
		if (idRegistro == null) {
			if (other.idRegistro != null)
				return false;
		} else if (!idRegistro.equals(other.idRegistro))
			return false;
		if (nota == null) {
			if (other.nota != null)
				return false;
		} else if (!nota.equals(other.nota))
			return false;
		if (sistema == null) {
			if (other.sistema != null)
				return false;
		} else if (!sistema.equals(other.sistema))
			return false;
		if (usuario == null) {
			if (other.usuario != null)
				return false;
		} else if (!usuario.equals(other.usuario))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return new StringBuffer()
		.append(" SYSTEM : " + sistema)
		.append(" USER : " + usuario)
		.append(" NOTE : " + nota)
		.append(" FIELD : " + campo)
		.toString();
	}	

}
