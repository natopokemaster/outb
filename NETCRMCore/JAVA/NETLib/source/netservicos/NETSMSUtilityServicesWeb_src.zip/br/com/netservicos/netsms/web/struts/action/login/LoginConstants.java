/**
 * Created on 28/06/2007
 * Project : NovoSMSWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: LoginConstants.java,v 1.3.6.1 2009/08/03 21:48:11 anvlassov Exp $
 */
package br.com.netservicos.netsms.web.struts.action.login;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * <P><B>Description :</B><BR>
 * 	TODO descrever
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author morvimen
 * @since 28/06/2007
 * @version $Revision: 1.3.6.1 $
 */
public interface LoginConstants {

   public final static String LOGIN_CONFIG = "net.web.loginconfig";
   
   public static enum LOGIN_CONFIG_PARAMETERS {
	       loadMenu,
	       loadBaseUserInfo,
	       loadPasswordStatus;
	       
	    public static Boolean validateValue(Map<String,String> loginConfig, LOGIN_CONFIG_PARAMETERS paramType) {
			if(loginConfig == null || loginConfig.isEmpty()) return false;
			String param = loginConfig.get(paramType.toString());
	    	if(StringUtils.isNotBlank(param) && Boolean.valueOf(param)) return true;
	    	else return false;
	    }
   }

}
