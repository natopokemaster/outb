//$Id: PreUpdateEventListener.java,v 1.1 2007/11/05 12:11:30 rmgray Exp $
package org.hibernate.event;

import java.io.Serializable;

/**
 * Called before updating the datastore
 * 
 * @author Gavin King
 */
public interface PreUpdateEventListener extends Serializable {
	public boolean onPreUpdate(PreUpdateEvent event);
}
