//$Id: CacheEntryStructure.java,v 1.1 2007/11/05 12:11:35 rmgray Exp $
package org.hibernate.cache.entry;

import org.hibernate.engine.SessionFactoryImplementor;



/**
 * @author Gavin King
 */
public interface CacheEntryStructure {
	public Object structure(Object item);
	public Object destructure(Object map, SessionFactoryImplementor factory);
}
