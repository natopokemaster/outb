/**
 * Created on 28/05/2007
 * Project : NETSMSUtilityServices
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: NETSMSLogAuditoriaMessageServiceEjbBean.java,v 1.7 2007/12/17 23:35:50 rmgray Exp $
 */
package br.com.netservicos.netsms.utilities.auditoria;

import java.sql.Types;
import java.util.Date;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.netservicos.framework.core.dao.BatchParameter;
import br.com.netservicos.framework.core.dao.DAO;
import br.com.netservicos.framework.core.jms.MessageService;
import br.com.netservicos.framework.util.BaseConstants;

/**
 * <P><B>Description :</B><BR>
 * 	JMS Client used to send the auditor messages 
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 28/05/2007
 * @version $Revision: 1.7 $
 *
 * @ejb.bean name="NETSMSLogAuditoriaMessageServiceEjbBean"
 * 		description="NETSMS JMS Service for to log auditor mesasges"
 *      destination-type="javax.jms.Queue"
 *      transaction-type="Container"
 *      local-jndi-name="jms/auditoria"
 *      acknowledge-mode="Auto-acknowledge"
 *      
 * @ejb.transaction type="RequiresNew"
 * 
 * @jboss.destination-jndi-name name="jms/auditoria"
 *  
 * @weblogic.pool 
 *      initial-beans-in-free-pool="20"
 *      max-beans-in-free-pool="200"
 *      
 * @weblogic.message-driven 
 * 		connection-factory-jndi-name="qcf/novosms"
 *      destination-jndi-name="jms/auditoria"
 * @ejb.env-entry
 *   	name="identifierApplication" type="java.lang.String" value="NETSMSUtilityServices"
 */
public class NETSMSLogAuditoriaMessageServiceEjbBean extends MessageService {

	/** Serial Version */
	private static final long serialVersionUID = 4034672313308347614L;
	
	private static final String CALLABLE_PROCEDURE_LAA_PLSQL = 
			"{call LAA_PLSQL( ?, ?, ?, ?, ?, ?, ?, ? )}";

	private static final String PARAMETER_NOTA = "pNota";
	
	private static final String PARAMETER_IDREGISTRO = "pIDRegistro";
	
	private static final String PARAMETER_CAMPO = "pCampo";
	
	private static final String PARAMETER_CIDADE = "pCidade";
	
	private static final String PARAMETER_ACAO = "pAcao";
	
	private static final String PARAMETER_CRITICIDADE = "pCriticidade";
	
	private static final String PARAMETER_USUARIO = "pUsuario";
	
	private static final String PARAMETER_SISTEMA = "pSistema";
	
	/** This constant represents the Log service instance */
	private static final transient Log log = LogFactory.getLog(
			NETSMSLogAuditoriaMessageServiceEjbBean.class);
	
	
	/**
	 * 
	 * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
	 */
	public void onMessage(Message msg) {
		
		ObjectMessage message = (ObjectMessage) msg;
		
		DAO dao;
		BatchParameter[] batchParameters;
		NETSMSLogAuditoria logAuditoria;
		
		try {
			
			if (log.isDebugEnabled()) {
				log.debug("JMS Auditor Server received message : " + message + ". Message Time : " 
						+ DateFormatUtils.format(new Date(message.getJMSTimestamp()), "dd/MM/yyyy HH:mm:ss"));
			}
			
			logAuditoria = (NETSMSLogAuditoria)message.getObject();
			dao = getApplicationResources().getDaoFactory().getDAO(DAO.JDBC_DAO, message.getStringProperty(BaseConstants.ATRIBUTO_DB_SERVICE ) );
			/*
			   LAA_PLSQL (pSistema in varchar2,
                           pUsuario in varchar2,
                           pCriticidade in number,
                           pAcao in number,
                           pCidade in varchar2,
                           pCampo in varchar2,
                           pIDRegistro in varchar2,
                           pNota in varchar2)
			 */
			batchParameters = new BatchParameter[ 8 ];
			
			batchParameters[ 0 ] = new BatchParameter( PARAMETER_SISTEMA, 
					logAuditoria.getSistema(), Types.VARCHAR, false );
			batchParameters[ 1 ] = new BatchParameter( PARAMETER_USUARIO, 
					logAuditoria.getUsuario(), Types.VARCHAR, false );
			batchParameters[ 2 ] = new BatchParameter( PARAMETER_CRITICIDADE, 
					logAuditoria.getCriticidade().getId(), Types.NUMERIC, false );
			batchParameters[ 3 ] = new BatchParameter( PARAMETER_ACAO, 
					logAuditoria.getAcao().getId(), Types.NUMERIC, false );
			batchParameters[ 4 ] = new BatchParameter( PARAMETER_CIDADE, 
					logAuditoria.getCidade(), Types.VARCHAR, false );
			batchParameters[ 5 ] = new BatchParameter( PARAMETER_CAMPO, 
					logAuditoria.getCampo(), Types.VARCHAR, false );
			batchParameters[ 6 ] = new BatchParameter( PARAMETER_IDREGISTRO, 
					logAuditoria.getIdRegistro(), Types.VARCHAR, false );
			batchParameters[ 7 ] = new BatchParameter( PARAMETER_NOTA, 
					logAuditoria.getNota(), Types.VARCHAR, false );
			
			dao.executeBatch( CALLABLE_PROCEDURE_LAA_PLSQL, batchParameters );
			
		} catch (JMSException e) {
			log.error( e.getMessage(), e );
		}
	}
}
