package net.sf.jasperreports.engine.design;

import net.sf.jasperreports.engine.base.JRBaseConditionalStyle;
import net.sf.jasperreports.engine.JRExpression;
import net.sf.jasperreports.engine.JRStyle;
import net.sf.jasperreports.engine.JRConditionalStyle;

/**
 * @author Ionut Nedelcu (ionutned@users.sourceforge.net)
 * @version $Id: JRDesignConditionalStyle.java,v 1.3 2006/02/06 14:36:56 teodord Exp $
 */
public class JRDesignConditionalStyle extends JRBaseConditionalStyle implements JRConditionalStyle
{

	/**
	 *
	 */
	public JRDesignConditionalStyle()
	{
	}

	/**
	 *
	 */
	public void setConditionExpression(JRExpression conditionExpression)
	{
		this.conditionExpression = conditionExpression;
	}

	/**
	 *
	 */
	public void setParentStyle(JRStyle parentStyle)
	{
		this.parentStyle = parentStyle;
	}

}
