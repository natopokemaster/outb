/**
 * Created on 23/07/2009
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: LoginActionSSO.java,v 1.1.2.3 2009/08/03 21:48:11 anvlassov Exp $
 */
package br.com.netservicos.netsms.web.struts.action.login;

import static br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants.ATTRIBUTO_PREFIXO_SECURITY_DBSERVICE;

import java.util.Collections;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import br.com.netservicos.framework.auth.util.jaas.BaseUser;
import br.com.netservicos.framework.auth.util.jaas.SecurityParametersEnum;
import br.com.netservicos.netsms.utilities.security.facade.NETSMSSecurityService;

/**
 * <P><B>Description :</B><BR>
 * LoginAction que dever� ser utilizada pelas aplica��es JEE que utilizam SSO. Customiza
 * comportamentos padr�es dos processos de Login
 * 
 * 1) obten��o do Menu a partir das bases de PERFIL no processo de Login
 * 2) obten��o da informa��o do usuario e expira��o de senha a partir do AD
 * 3) diferencia��o entre comportamento de senha expirada e senha a expirar
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Anton Vlassov
 * @since 23/07/2009
 */
public abstract class LoginActionSSO extends LoginAction {

	
	/**
	 * Obtem o menu a partir do banco de dados do Perfil, caso configurado no web app layer
	 * @since 23/07/2009
	 * @param request
	 * @return
	 */
	@Override
	protected Object getMenu(HttpServletRequest request) {
		
		if(loadMenu()) {
			String securityCurrentdbService = 
		    super.getUserInfo(request).getCurrentDbService().
			          replace(getPrefixoDatabaseService(), ATTRIBUTO_PREFIXO_SECURITY_DBSERVICE);
		
			NETSMSSecurityService securityService = super.getService(NETSMSSecurityService.class , request);
			return securityService.getMenu(request.getUserPrincipal().getName(),securityCurrentdbService);
		} else return Collections.EMPTY_MAP; 
			
		
	}
	
	/**
	 * Obtem as informa��es do BaseUser - usuario base a partir do AD, caso configurado no web app layer
	 * Como carga do status de senha depende de previamente ter carregado as informa��es do usuario,
	 * qquer um dos flags setados ativa a carga das informa��es 
	 * 
	 * @see br.com.netservicos.netsms.web.struts.action.login.LoginAction#getBaseUser(java.security.Principal)
	 */
	@Override
	protected BaseUser getBaseUser(HttpServletRequest request){
		if(loadBaseUserInfo() || loadPasswordStatus()) {
			NETSMSSecurityService securityService = super.getService(NETSMSSecurityService.class , request);
			return securityService.getBaseUser(request.getUserPrincipal().getName(),loadPasswordStatus());
		} else return new BaseUser(request.getUserPrincipal().getName());
	}
	
	/**
	 * 
	 * @see br.com.netservicos.netsms.web.struts.action.login.LoginAction#validatePasswordExpiration(javax.servlet.http.HttpServletRequest, org.apache.struts.action.ActionMapping)
	 */
	@Override
	protected boolean validatePasswordExpiration( HttpServletRequest request, ActionMapping mapping ) 	{
		
		BaseUser baseUser = super.getUserInfo(request).getUserInformations();
		
		if(baseUser != null) {
			if( baseUser.getPasswordAttribute(SecurityParametersEnum.USER_PASSWORD_EXPIRED).equals(Boolean.TRUE) ) {
				request.setAttribute(ATRIBUTO_SENHA_EXPIRADA, true);
				request.getSession().setAttribute(ATRIBUTO_SENHA_EXPIRADA, true);
				ActionMessages messages = new ActionMessages();
				messages.add("senhaExpirou", new ActionMessage("login.senhaexpiradawarning"));
				super.addMessages(request, messages);
				return true;
			} else if (baseUser.getPasswordAttribute(SecurityParametersEnum.USER_PASSWORD_EXPIRING).equals(Boolean.TRUE) ) {
				request.setAttribute(ATRIBUTO_SENHA_EXPIRADA, false);
	  		    request.setAttribute(ATRIBUTO_SENHA_EXPIRADA, baseUser.getPasswordAttribute(SecurityParametersEnum.USER_PASSWORD_EXPIRING_DAYS));
	  		    return true;
			}
		} 
		
		return false;
	}
	
	
	/**
	 * Todos os acessos entre as aplica��es para as funcionalidades diretamente, entre as aplica��es
	 * de SSO do mesmo circle of trust, devem ser efetuadas atraves desta Action.
	 * 
	 * Quando chamar esta Action a partir de uma outra aplica��o, o usuario j� estar�
	 * autenticado numa determinada base e possuir� devidas roles.
	 * 
	 * Pressupoe que o Perfil entre todas as bases ser� unificado, para que nao seja necessario
	 * recarregar as roles. 
	 * 
	 * @since 30/07/2009
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@Override
	public ActionForward externalLogin(ActionMapping mapping, 
			   ActionForm form, 
			   HttpServletRequest request, 
			   HttpServletResponse response) throws Exception {
		
		ActionForward actionForward = null;
		
		if (request.getParameter(SecurityParametersEnum.IDENTIFICATION_URL.identifier) != null ) {
		       
				processLogin(mapping, form, request, response);
				
				request.getRequestDispatcher(request.getParameter(SecurityParametersEnum.IDENTIFICATION_URL.identifier)).forward(
						request, response);
			
		} else {
			// PROIBIDO envia c�digo de status 401
			response.sendError( HttpServletResponse.SC_FORBIDDEN );
		}
		return actionForward;
		
	}
	
	/**
	 * Quando acesso � feito a partir do VB, ou qualquer outra aplica��o que solicita o
	 * acesso enviando um formulario POST com as informa��es necessarias,
	 * deve utilizar esta action, que serve como uma transforma��o de dados do POST
	 * para o formato GET e direciona para URI de /externalLogin, configurada
	 * no Weblogic para ser interceptada e redirecionada para ITS afim
	 * de efetuar autentica��o program�tica e direcionar para URI solicitada no 
	 * campo J_URL
	 * @since 21/08/2009
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward externalLoginLegado(ActionMapping mapping, 
			   ActionForm form, 
			   HttpServletRequest request, 
			   HttpServletResponse response) throws Exception {
		
		ActionForward actionForward = null;
		
		if (request.getParameter(SecurityParametersEnum.IDENTIFICATION_URL.identifier) != null
				&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_USERNAME.identifier) != null
				&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_PASSWORD.identifier) != null
				&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_DATABASE.identifier) != null
				&& request.getParameter(SecurityParametersEnum.IDENTIFICATION_SYSTEM.identifier) != null ) {
		       
				request.getRequestDispatcher("/externalLogin.do").forward(
						request, response);
			
		} else {
			// PROIBIDO envia c�digo de status 401
			response.sendError( HttpServletResponse.SC_FORBIDDEN );
		}
		return actionForward;
		
	}
	
	
	/**
	 * Verifica se o web layer est� configurado para que o menu seja carregado
	 * @since 03/08/2009
	 * @return
	 */
	private Boolean loadMenu() {
		return LoginConstants.LOGIN_CONFIG_PARAMETERS.validateValue(getLoginConfig(),LoginConstants.LOGIN_CONFIG_PARAMETERS.loadMenu);
	}
	
	/**
	 * Verifica se o web layer est� configurado para que base user info seja carregado
	 * @since 03/08/2009
	 * @return
	 */
	private Boolean loadBaseUserInfo() {
		return LoginConstants.LOGIN_CONFIG_PARAMETERS.validateValue(getLoginConfig(),LoginConstants.LOGIN_CONFIG_PARAMETERS.loadBaseUserInfo);
	}
	
	/**
	 	 * Verifica se o web layer est� configurado para o status da senha seja carregado
	 * @since 03/08/2009
	 * @return
	 */
	private Boolean loadPasswordStatus() {
		return LoginConstants.LOGIN_CONFIG_PARAMETERS.validateValue(getLoginConfig(),LoginConstants.LOGIN_CONFIG_PARAMETERS.loadPasswordStatus);
	}
	
	/**
	 * Recupera as ocnfigura��es do Login do applicationWebLayer
	 * @since 03/08/2009
	 * @return
	 */
	private Map<String,String> getLoginConfig() {
		return (Map<String,String>)super.getWebContext().lookup(LoginConstants.LOGIN_CONFIG);
	}
	

}
