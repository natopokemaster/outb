/**
 * Created on 24/07/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: OperatorSelectUtils.java,v 1.2 2007/07/26 01:12:29 rmgray Exp $
 */
package br.com.netservicos.netsms.web.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.netservicos.netsms.utilities.operator.bean.OperatorDTO;
import br.com.netservicos.netsms.web.taglib.ui.OperatorSelectTag;

/**
 * <P><B>Description :</B><BR>
 * 	Utility class used to retrieve the information created by the the taglib OperatorSelectTag
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 24/07/2007
 * @version $Revision: 1.2 $
 * @see OperatorSelectTag
 */
public class OperatorSelectUtils {
	
	/** This constant represents the Log service instance */
	private static final Log log = LogFactory.getLog(OperatorSelectUtils.class);
	
	/**
	 * Retrieves the selected operator
	 * @since 24/07/2007
	 * @param request HttpServletRequest
	 * @param nameParameter Name of the parameter for the select
	 * @return OperatorDTO for the selected operator, null if a operator is not selected
	 */
	public static OperatorDTO getSelectedOperator(HttpServletRequest request, String nameParameter) {
		
		OperatorDTO operator = null;
		
		String operatorSelected = request.getParameter(nameParameter);
		
		if (!StringUtils.isBlank(operatorSelected)) {
			String[] strings 		= operatorSelected.split("\\|");
			operator = new OperatorDTO(strings[0], strings[1]);
		} else {
			log.debug("Operator not selected (parameter name = " + nameParameter + ").");
		}
		return operator;
	}
	
	/**
	 * Retrieves the selected operators from a multiple select
	 * @since 24/07/2007
	 * @param request HttpServletRequest
	 * @param nameParameter Name of the parameter for the select
	 * @return Collection of operators that where selected
	 */
	public static Collection<OperatorDTO> getSelectedOperators(HttpServletRequest request, String nameParameter) {
		return getSelectedOperators(request, nameParameter, null);
	}

	/**
	 * Retrieves the selected operators from a multiple select
	 * @since 24/07/2007
	 * @param request HttpServletRequest
	 * @param nameParameter Name of the parameter for the select
	 * @param ordering Comparator to order the selected operators
	 * @return Collection of operators that where selected
	 */
	public static Collection<OperatorDTO> getSelectedOperators(HttpServletRequest request, String nameParameter, Comparator<OperatorDTO> ordering) {
		
		List<OperatorDTO> operators = new ArrayList<OperatorDTO>();
		String[] operatorsSelected = request.getParameterValues(nameParameter);
		
		if (operatorsSelected == null || operatorsSelected.length < 1) {
			
			for (int i = 0; i < operatorsSelected.length; i++) {
				OperatorDTO operator = null;
				String[] strings 		= operatorsSelected[i].split("\\|");
				operator = new OperatorDTO(strings[0], strings[1]);
				operators.add(operator);
			}
			if (ordering != null) {
				Collections.sort(operators, ordering);
			}
			
		} else {
			OperatorDTO operator = getSelectedOperator(request, nameParameter);
			if (operator != null) {
				operators.add(operator);
			} else {
				log.debug("Operator not selected (parameter name = " + nameParameter + ").");
			}
		}
		return operators;
	}


	/**
	 * 
	 * <P><B>Description :</B><BR>
	 * 	Implementation of a comparator that compares the database services of the Operators<br>
	 * If used to sort a list of OperatorDTO's the order will be by Database Service 
	 * </P>
	 * <P>
	 * <B>
	 * Issues : <BR>
	 * None
	 * </B>
	 * @author Robin Michael Gray
	 * @since 25/07/2007
	 * @version $Revision: 1.2 $
	 */
	public class OperatorBaseComparator implements Comparator<OperatorDTO > {

		/**
		 * Compare the Database Services
		 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
		 */
		public int compare(OperatorDTO o1, OperatorDTO o2) {
			if (o1.getDbService() == null || o2.getDbService() == null) {
				return -1;
			}
			return o1.getDbService().compareTo(o2.getDbService());
		}
		
	}
	
	/**
	 * 
	 * <P><B>Description :</B><BR>
	 * 	Implementation of a comparator that compares the CidContrato's of the Operators<br>
	 * If used to sort a list of OperatorDTO's the order will be by their CidContrato
	 * </P>
	 * <P>
	 * <B>
	 * Issues : <BR>
	 * None
	 * </B>
	 * @author Robin Michael Gray
	 * @since 25/07/2007
	 * @version $Revision: 1.2 $
	 */
	public class OperatorCidContratoComparator implements Comparator<OperatorDTO > {

		/**
		 * Compare the Cid Contratos
		 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
		 */
		public int compare(OperatorDTO o1, OperatorDTO o2) {
			if (o1.getCidContrato() == null || o2.getCidContrato() == null) {
				return -1;
			}
			return o1.getCidContrato().compareTo(o2.getCidContrato());
		}
		
	}
	
	/**
	 * 
	 * <P><B>Description :</B><BR>
	 * 	Implementation of a comparator that compares the Name's of the Operators<br>
	 * If used to sort a list of OperatorDTO's the order will be by their names
	 * </P>
	 * <P>
	 * <B>
	 * Issues : <BR>
	 * None
	 * </B>
	 * @author Robin Michael Gray
	 * @since 25/07/2007
	 * @version $Revision: 1.2 $
	 */
	public class OperatorNameComparator implements Comparator<OperatorDTO > {

		/**
		 * Compare the Name of the operator
		 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
		 */
		public int compare(OperatorDTO o1, OperatorDTO o2) {
			if (o1.getNameOperator() == null || o2.getNameOperator() == null) {
				return -1;
			}
			return o1.getNameOperator().compareTo(o2.getNameOperator());
		}
		
	}
	
}
