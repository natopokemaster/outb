//$Id: TransientObjectException.java,v 1.1 2007/11/05 12:11:30 rmgray Exp $
package org.hibernate;

/**
 * Thrown when the user passes a transient instance to a <tt>Session</tt>
 * method that expects a persistent instance.
 *
 * @author Gavin King
 */

public class TransientObjectException extends HibernateException {

	public TransientObjectException(String s) {
		super(s);
	}

}






