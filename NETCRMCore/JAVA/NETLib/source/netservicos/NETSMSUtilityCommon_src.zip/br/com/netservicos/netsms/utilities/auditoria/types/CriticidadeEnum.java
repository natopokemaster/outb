/**
 * Created on 31/05/2007
 * Project : NETSMSUtilityServices
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: CriticidadeEnum.java,v 1.1 2007/07/26 00:35:25 rmgray Exp $
 */
package br.com.netservicos.netsms.utilities.auditoria.types;

import java.io.Serializable;

/**
 * <P><B>Description :</B><BR>
 * 	Define o nivel de criticidade
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author morvimen
 * @since 31/05/2007
 * @version $Revision: 1.1 $
 */
public enum CriticidadeEnum implements Serializable{

	MUITO_BAIXA(1),
	BAIXA(2),
	MEDIA(3),
	ALTO(4),
	MUITO_ALTO(5);
	
	private int id;
	
	/**
	 * @since 31/05/2007
	 * @param id
	 */
	private CriticidadeEnum( int id ) {
		this.id = id;
	}

	/**
	 * @return the id
	 */
	public final int getId() {
		return id;
	}
}
