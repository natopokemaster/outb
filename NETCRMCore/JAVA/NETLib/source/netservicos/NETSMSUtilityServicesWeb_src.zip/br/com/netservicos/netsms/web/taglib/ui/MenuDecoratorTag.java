/**
 * Created on 11/09/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: MenuDecoratorTag.java,v 1.3.22.1 2009/07/29 18:28:05 anvlassov Exp $
 */
package br.com.netservicos.netsms.web.taglib.ui;

import java.util.Iterator;
import java.util.Map;

/**
 * <P><B>Description :</B><BR>
 * 	TODO descrever
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 11/09/2007
 * @version $Revision: 1.3.22.1 $
 * 
 * @author Anton Vlassov
 * @since 29/07/2007
 * @version $Revision: 1.3.22.1 $
 * metodo montarURL corrigido para nao gerar duplas e triplas barras, corrigido o replace.all() que nao atribuia o resultado
 * a uma string
 */
public class MenuDecoratorTag extends MenuTag {
	/**
	 * URL for the blank page so that HTTPS is not broken
	 */
	private String blankPageURL;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3862559631280687305L;

	/**
	 * 
	 * @see br.com.netservicos.netsms.web.taglib.ui.MenuTag#montaMenu(java.util.Map)
	 */
	@Override
	protected String montaMenu(Map itens) {
		StringBuilder builder = new StringBuilder();
		int indice = 1;
		
		if (itens.size() > 0) {
			builder.append("<div id='menu_itens'><iframe id='iFrameMenu' src='"+this.getBlankPageURL()+"'></iframe>\n");
			builder.append("<ul id='nav'>\n");
	
			gerarMenu(builder,itens,indice,1);
	
			builder.append("</ul></div>\n");
		}
		return builder.toString();
	}

	/**
	 * 
	 *<li><a href="#">Endere�os</a>
	 *<ul>
	 *	<li><a href="#">Manuten��es</a></li>
	 *	<ul>
	 *		<li><a href="pages/empreiteira.htm">Empreiteiras</a></li>
	 *		<li><a href="pages/distrito.htm">Distritos</a></li>
	 *		<li><a href="pages/tipoObservacao.htm">Tipos de Observa��es</a></li>
	 *		<li><a href="pages/bairro.htm">Bairros</a></li>
	 *		<li><a href="pages/condominio.htm">Condom�nios</a></li>
	 *		<li><a href="pages/material.htm">Materiais</a></li>
	 *	</ul>
	 *</ul>
	 *<li><a href="#">Terminais</a></li>
	 *<li><a href="#">Redes</a></li>
	 * 
	 * @see br.com.netservicos.netsms.web.taglib.ui.MenuTag#gerarMenu(java.lang.StringBuilder, java.util.Map, int, int)
	 */
	@Override
	protected void gerarMenu(StringBuilder builder, Map menu, int indice,
			int level) {

		int index = 0;

		if (level != 1) {
			builder.append("<ul>");
		}

		for (Iterator iterator = menu.entrySet().iterator(); iterator.hasNext();) {

			Map.Entry<String, Object> entry = (Map.Entry<String, Object>) iterator.next();

			Map<String,Object> nivel2 =null;
			index++;

			if(entry.getValue() != null && Map.class.isInstance( entry.getValue() )){
				
				if (hasChildLinks(entry)) {
				
					nivel2 = (Map)entry.getValue();
					if (nivel2 != null && nivel2.size() > 0) {
						builder.append("<li><a href='#'>"+entry.getKey()+"</a>\n");
		
						gerarMenu(builder,nivel2,indice + (index * (int)Math.pow(10, level )),level+1);
					}
				
				}

			} else {

				builder.append("<li><a href=" + montarURL( String.valueOf(entry.getValue())) +">"+entry.getKey()+"</a></li>\n");

			}
		}

		if (level != 1) {
			builder.append("</ul>\n");
		}

	}
	
	private Boolean hasChildLinks(Map.Entry<String, Object> menuItem) {
		
		Boolean hasChildLinks = Boolean.FALSE;
		
		if(menuItem.getValue() != null && Map.class.isInstance( menuItem.getValue() )){
			Map subMenuItens = (Map) menuItem.getValue();
			for (Iterator iterator = subMenuItens.entrySet().iterator(); iterator.hasNext();) {
				Map.Entry<String, Object> entry = (Map.Entry<String, Object>) iterator.next();
				hasChildLinks = hasChildLinks(entry);
				if (hasChildLinks) {
					break;
				}
			}
			
		} else if (menuItem.getValue() != null) {
			hasChildLinks =  Boolean.TRUE;
		}
		
		return hasChildLinks;
	}

	private String montarURL(String urlRelativo) {
		String url = urlPrefixo + urlRelativo;
		url = url.replaceAll("\"", "").replaceAll("\'", "").replaceAll("/+", "/").replaceFirst("/", "//");
		return "javascript:selectMenu('" + url + "');";
	}

	/**
	 * @return the blankPageURL
	 */
	public String getBlankPageURL() {
		return blankPageURL;
	}

	/**
	 * @param blankPageURL the blankPageURL to set
	 */
	public void setBlankPageURL(String blankPageURL) {
		this.blankPageURL = blankPageURL;
	}





}
