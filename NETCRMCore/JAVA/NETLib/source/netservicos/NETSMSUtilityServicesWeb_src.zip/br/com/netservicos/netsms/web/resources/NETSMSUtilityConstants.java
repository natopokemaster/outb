/**
 * Created on 20/07/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: NETSMSUtilityConstants.java,v 1.3.12.2 2009/07/31 21:08:57 anvlassov Exp $
 */
package br.com.netservicos.netsms.web.resources;

/**
 * <P><B>Description :</B><BR>
 * 	TODO descrever
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 20/07/2007
 * @version $Revision: 1.3.12.2 $
 */
public class NETSMSUtilityConstants {

	/**
	 * Key used to store the current operator name
	 */
	public static final String KEY_CURRENT_OPERATOR_NAME = "CURRENT_OPERATOR_NAME";

	/**
	 * Key used to store the current cid contrato
	 */
	public static final String KEY_CURRENT_CID_CONTRATO = "CURRENT_CID_CONTRATO";
	
	/**
	 * Key used to store the menu of the user
	 */
	public static final String ATTRIBUTE_MENU = "userMenu";
	
	public static final String ATTRIBUTO_PREFIXO_DBSERVICE = "PREFIXO_DBSERVICE";
	
	public static final String ATTRIBUTO_PREFIXO_DBSERVICE_PER_APPLICATION = "PREFIXO_DBSERVICE_PER_APPLICATION";
	
	public static final String ATTRIBUTO_PREFIXO_SECURITY_DBSERVICE = "PERFIL_";
	
	public static final String ATTRIBUTO_LIMITED_SYSTEM_ACCESS = "LIMITED_SYSTEM_ACCESS";
	
	
}
