package br.com.netservicos.netsms.web.struts.action.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * 
 * <P><B>Description :</B><BR>
 * 	Interface that declares the public methods which must be implemented for applications that require SSO
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 20/09/2007
 * @version $Revision: 1.1 $
 */
public interface SingleSignOnAction {

	/**
	 * Signs on the user who has already be authenticated
	 * @since 20/09/2007
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return forward
	 * @throws Exception
	 */
	public abstract ActionForward singleSignOn(ActionMapping mapping, 
			   ActionForm form, 
			   HttpServletRequest request, 
			   HttpServletResponse response) throws Exception ;
	
}
