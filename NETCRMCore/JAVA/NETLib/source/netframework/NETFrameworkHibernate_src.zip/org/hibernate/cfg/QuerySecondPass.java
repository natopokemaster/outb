//$Id: QuerySecondPass.java,v 1.1 2007/11/05 12:11:35 rmgray Exp $
package org.hibernate.cfg;

/**
 * Bind query
 *
 * @author Emmanuel Bernard
 */
public interface QuerySecondPass extends SecondPass {
}
