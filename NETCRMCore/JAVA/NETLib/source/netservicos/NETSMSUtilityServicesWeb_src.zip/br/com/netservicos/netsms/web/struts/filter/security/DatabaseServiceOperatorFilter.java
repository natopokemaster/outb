/**
 * Created on 08/09/2007
 * Project : NETSMSUtilityServicesWeb
 *
 * Copyright � 2007 NET.
 * Brasil
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of NET. 
 * You shall not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Net Servi�os.
 * 
 * $Id: DatabaseServiceOperatorFilter.java,v 1.2 2007/11/03 16:48:23 rmgray Exp $
 */
package br.com.netservicos.netsms.web.struts.filter.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import br.com.netservicos.framework.core.bean.UserInfo;
import br.com.netservicos.framework.web.BaseFilter;
import br.com.netservicos.netsms.web.resources.NETSMSUtilityConstants;



/**
 * <P><B>Description :</B><BR>
 * 	TODO descrever
 * </P>
 * <P>
 * <B>
 * Issues : <BR>
 * None
 * </B>
 * @author Robin Michael Gray
 * @since 08/09/2007
 * @version $Revision: 1.2 $
 */
public abstract class DatabaseServiceOperatorFilter extends BaseFilter {

	private static final Log log = LogFactory.getLog(DatabaseServiceOperatorFilter.class);
	
	
	private String urlSelectOperator;
	
	/**
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		if (log.isDebugEnabled()) {
			log.debug("Processing the init() method of Database Service Operator Servlet Filter.");
		}
		urlSelectOperator = filterConfig.getInitParameter("urlSelectOperator");
	}


	/**
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws IOException, ServletException {
		
		
		UserInfo userInfo = getUserInfo((HttpServletRequest)request);
		if (userInfo != null) {
			
			String currentDBService = userInfo.getCurrentDbService();
			if (!StringUtils.isBlank(currentDBService)) {

				String operatorName = userInfo.getProperties().getProperty(NETSMSUtilityConstants.KEY_CURRENT_OPERATOR_NAME);
				if (StringUtils.isBlank(operatorName)) {
					String cidContrato = userInfo.getProperties().getProperty(NETSMSUtilityConstants.KEY_CURRENT_CID_CONTRATO);
					
					if (!StringUtils.isBlank(cidContrato)) {
						operatorName = this.getOperatorName(request, cidContrato);
						userInfo.getProperties().setProperty(NETSMSUtilityConstants.KEY_CURRENT_OPERATOR_NAME, operatorName);
					} else {
						
						if (log.isDebugEnabled()) {
							log.debug("Forwarding user to select a operator. The property " + NETSMSUtilityConstants.KEY_CURRENT_CID_CONTRATO 
									+ " is not configured in the UserInfo");
						}
						
						this.forwardToSelectOperator(request, response);
						return;
					}
				}
			} else {
				if (log.isDebugEnabled()) {
					log.debug("Forwarding user to select a operator. The user does not have a database service selected.");
				}
				
				this.forwardToSelectOperator(request, response);
				return;
			}
		} else {
			if (log.isDebugEnabled()) {
				log.debug("User Info not found in the session not validating the operator");
			}
		}
		
		filterChain.doFilter(request, response);
	}
	
	
	private void forwardToSelectOperator(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher(urlSelectOperator).forward(request, response);
	}
	
	public abstract String getOperatorName(ServletRequest request, String cidContrato);


	/**
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		if (log.isDebugEnabled()) {
			log.debug("Processing the destroy() method of Database Service Operator Servlet Filter.");
		}
	}

}
