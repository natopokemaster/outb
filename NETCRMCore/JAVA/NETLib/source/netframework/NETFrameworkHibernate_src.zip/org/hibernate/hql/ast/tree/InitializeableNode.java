// $Id: InitializeableNode.java,v 1.1 2007/11/05 12:11:29 rmgray Exp $

package org.hibernate.hql.ast.tree;

/**
 * An interface for initializeable AST nodes.
 */
public interface InitializeableNode {
	/**
	 * Initializes the node with the parameter.
	 *
	 * @param param the initialization parameter.
	 */
	void initialize(Object param);
}
